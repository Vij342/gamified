import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { 
  Mic, 
  MicOff, 
  Volume2, 
  CheckCircle, 
  XCircle, 
  ArrowLeft,
  Brain,
  Target,
  Flame,
  Home
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner@2.0.3";

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
  voiceAnswer?: string; // What the voice recognition should listen for
}

interface InteractiveQuizProps {
  subject: string;
  onBack: () => void;
  onComplete: (score: number, xpEarned: number) => void;
}

const interactiveQuestions: Record<string, Question[]> = {
  math: [
    {
      id: "1",
      question: "What is ¾ as a decimal?",
      options: ["0.25", "0.5", "0.75", "1.0"],
      correctAnswer: 2,
      explanation: "¾ = 3 ÷ 4 = 0.75",
      difficulty: "easy",
      voiceAnswer: "three fourths"
    },
    {
      id: "2",
      question: "Solve: 12 + 8 × 2",
      options: ["32", "28", "40", "20"],
      correctAnswer: 1,
      explanation: "Following order of operations: 12 + (8 × 2) = 12 + 16 = 28",
      difficulty: "medium",
      voiceAnswer: "twenty eight"
    },
    {
      id: "3",
      question: "What is the area of a rectangle with length 6 and width 4?",
      options: ["10", "20", "24", "14"],
      correctAnswer: 2,
      explanation: "Area = length × width = 6 × 4 = 24 square units",
      difficulty: "easy",
      voiceAnswer: "twenty four"
    }
  ],
  science: [
    {
      id: "1",
      question: "What gas do plants absorb during photosynthesis?",
      options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"],
      correctAnswer: 1,
      explanation: "Plants absorb carbon dioxide and release oxygen during photosynthesis",
      difficulty: "easy",
      voiceAnswer: "carbon dioxide"
    },
    {
      id: "2",
      question: "How many bones are in the adult human body?",
      options: ["196", "206", "216", "226"],
      correctAnswer: 1,
      explanation: "Adults have 206 bones, while babies are born with about 270 bones",
      difficulty: "medium",
      voiceAnswer: "two hundred six"
    }
  ]
};

export function InteractiveQuiz({ subject, onBack, onComplete }: InteractiveQuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [questions] = useState(interactiveQuestions[subject] || interactiveQuestions.math);
  const [isListening, setIsListening] = useState(false);
  const [voiceInput, setVoiceInput] = useState("");
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [recognition, setRecognition] = useState<SpeechRecognition | null>(null);

  useEffect(() => {
    // Check for speech recognition support
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      setVoiceSupported(true);
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = false;
      recognitionInstance.lang = 'en-US';
      
      recognitionInstance.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        setVoiceInput(transcript);
        handleVoiceAnswer(transcript);
      };
      
      recognitionInstance.onerror = (event) => {
        setIsListening(false);
        toast.error("Voice recognition error. Please try again.");
      };
      
      recognitionInstance.onend = () => {
        setIsListening(false);
      };
      
      setRecognition(recognitionInstance);
    }
  }, []);

  const startListening = () => {
    if (recognition && !isAnswered) {
      setIsListening(true);
      setVoiceInput("");
      recognition.start();
    }
  };

  const stopListening = () => {
    if (recognition) {
      recognition.stop();
      setIsListening(false);
    }
  };

  const handleVoiceAnswer = (transcript: string) => {
    const currentQ = questions[currentQuestion];
    
    // Check if voice input matches expected answer
    if (currentQ.voiceAnswer && transcript.includes(currentQ.voiceAnswer)) {
      handleAnswer(currentQ.correctAnswer);
      toast.success(`Correct! "${transcript}"`);
    } else {
      // Try to match with option text
      const matchedOptionIndex = currentQ.options.findIndex(option => 
        transcript.includes(option.toLowerCase()) ||
        option.toLowerCase().includes(transcript)
      );
      
      if (matchedOptionIndex !== -1) {
        handleAnswer(matchedOptionIndex);
        toast.info(`You said: "${transcript}"`);
      } else {
        toast.error("Could not understand your answer. Please try again.");
      }
    }
  };

  const speakQuestion = () => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(questions[currentQuestion].question);
      utterance.rate = 0.8;
      speechSynthesis.speak(utterance);
    }
  };

  const handleAnswer = (answerIndex: number) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answerIndex);
    setIsAnswered(true);
    
    const isCorrect = answerIndex === questions[currentQuestion].correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
      setStreak(streak + 1);
    } else {
      setStreak(0);
    }
    
    setShowResult(true);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsAnswered(false);
      setVoiceInput("");
    } else {
      // Quiz complete
      const finalScore = score + (selectedAnswer === questions[currentQuestion].correctAnswer ? 1 : 0);
      const xpEarned = Math.round((finalScore / questions.length) * 100 + streak * 10);
      onComplete(finalScore, xpEarned);
    }
  };

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const isCorrect = selectedAnswer === currentQ.correctAnswer;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
            <Home className="h-4 w-4" />
            Back to Dashboard
          </Button>
          
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Brain className="h-3 w-3" />
              Question {currentQuestion + 1}/{questions.length}
            </Badge>
            
            <Badge variant="secondary" className="flex items-center gap-1">
              <Target className="h-3 w-3" />
              Score: {score}/{questions.length}
            </Badge>
            
            {streak > 0 && (
              <Badge className="bg-orange-500 flex items-center gap-1">
                <Flame className="h-3 w-3" />
                Streak: {streak}
              </Badge>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={progress} className="h-3" />
        </div>

        {/* Quiz Card */}
        <Card className="shadow-xl border-0">
          <CardHeader className="bg-gradient-to-r from-green-500 to-blue-500 text-white rounded-t-lg">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Interactive Quiz</CardTitle>
              <div className="flex items-center gap-2">
                <Badge 
                  className={`${
                    currentQ.difficulty === 'easy' ? 'bg-green-500' :
                    currentQ.difficulty === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                >
                  {currentQ.difficulty}
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={speakQuestion}
                  className="text-white hover:bg-white/20"
                >
                  <Volume2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-semibold mb-8 text-center">
                  {currentQ.question}
                </h2>

                {/* Voice Input Section */}
                {voiceSupported && (
                  <div className="mb-6 p-4 bg-blue-50 rounded-lg border">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-blue-800">Voice Answer</h3>
                      <Button
                        variant={isListening ? "destructive" : "default"}
                        size="sm"
                        onClick={isListening ? stopListening : startListening}
                        disabled={isAnswered}
                        className="flex items-center gap-2"
                      >
                        {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                        {isListening ? "Stop Listening" : "Speak your answer"}
                      </Button>
                    </div>
                    
                    {isListening && (
                      <motion.div
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ duration: 1, repeat: Infinity }}
                        className="text-center text-blue-600"
                      >
                        🎤 Listening... Say your answer clearly
                      </motion.div>
                    )}
                    
                    {voiceInput && (
                      <div className="mt-2 p-2 bg-white rounded border">
                        <span className="text-sm text-gray-600">You said: </span>
                        <span className="font-medium">"{voiceInput}"</span>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {currentQ.options.map((option, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ scale: isAnswered ? 1 : 1.02 }}
                      whileTap={{ scale: isAnswered ? 1 : 0.98 }}
                    >
                      <Button
                        variant={
                          showResult
                            ? index === currentQ.correctAnswer
                              ? "default"
                              : index === selectedAnswer
                              ? "destructive"
                              : "outline"
                            : selectedAnswer === index
                            ? "default"
                            : "outline"
                        }
                        className={`w-full p-6 h-auto text-left justify-start text-wrap ${
                          showResult && index === currentQ.correctAnswer
                            ? "bg-green-500 hover:bg-green-600 border-green-500"
                            : showResult && index === selectedAnswer && !isCorrect
                            ? "bg-red-500 hover:bg-red-600 border-red-500"
                            : ""
                        }`}
                        onClick={() => handleAnswer(index)}
                        disabled={isAnswered}
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-current opacity-20 flex items-center justify-center">
                            <span className="font-bold text-current opacity-100">
                              {String.fromCharCode(65 + index)}
                            </span>
                          </div>
                          <span>{option}</span>
                          
                          {showResult && index === currentQ.correctAnswer && (
                            <CheckCircle className="h-5 w-5 ml-auto text-white" />
                          )}
                          {showResult && index === selectedAnswer && !isCorrect && (
                            <XCircle className="h-5 w-5 ml-auto text-white" />
                          )}
                        </div>
                      </Button>
                    </motion.div>
                  ))}
                </div>

                {showResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-lg mb-6 ${
                      isCorrect ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      {isCorrect ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                      <span className={`font-semibold ${isCorrect ? "text-green-800" : "text-red-800"}`}>
                        {isCorrect ? "Correct!" : "Incorrect"}
                      </span>
                      {isCorrect && streak > 1 && (
                        <Badge className="bg-orange-500 ml-2">
                          <Flame className="h-3 w-3 mr-1" />
                          {streak} in a row!
                        </Badge>
                      )}
                    </div>
                    <p className={isCorrect ? "text-green-700" : "text-red-700"}>
                      {currentQ.explanation}
                    </p>
                  </motion.div>
                )}

                {showResult && (
                  <div className="text-center">
                    <Button onClick={nextQuestion} size="lg" className="min-w-32">
                      {currentQuestion < questions.length - 1 ? "Next Question" : "Finish Quiz"}
                    </Button>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}