import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Globe, ChevronDown, Check } from "lucide-react";
import { SUPPORTED_LANGUAGES, Language, translate } from "../utils/languages";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ScrollArea } from "./ui/scroll-area";

interface LanguageSelectorProps {
  selectedLanguage: string;
  onLanguageChange: (languageCode: string) => void;
  onConfirm?: () => void;
  showConfirmButton?: boolean;
  compact?: boolean;
  currentTranslations?: Record<string, string>;
}

export function LanguageSelector({
  selectedLanguage,
  onLanguageChange,
  onConfirm,
  showConfirmButton = false,
  compact = false,
  currentTranslations = {}
}: LanguageSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const selectedLang = SUPPORTED_LANGUAGES.find(lang => lang.code === selectedLanguage);
  
  const filteredLanguages = SUPPORTED_LANGUAGES.filter(lang =>
    lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lang.nativeName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleLanguageSelect = (languageCode: string) => {
    onLanguageChange(languageCode);
    setIsOpen(false);
    setSearchTerm("");
  };

  if (compact) {
    return (
      <div className="relative">
        <Button
          variant="outline"
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-2 min-w-[140px]"
        >
          <Globe className="w-4 h-4" />
          <span className="text-sm">{selectedLang?.flag} {selectedLang?.nativeName}</span>
          <ChevronDown className="w-3 h-3" />
        </Button>

        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute top-full left-0 right-0 z-50 mt-1"
          >
            <Card className="p-2 max-h-64 overflow-hidden">
              <ScrollArea className="max-h-56">
                <div className="space-y-1">
                  {filteredLanguages.map((language) => (
                    <button
                      key={language.code}
                      onClick={() => handleLanguageSelect(language.code)}
                      className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-accent transition-colors text-left"
                    >
                      <span className="text-lg">{language.flag}</span>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm">{language.nativeName}</div>
                        <div className="text-xs text-muted-foreground">{language.name}</div>
                      </div>
                      {selectedLanguage === language.code && (
                        <Check className="w-4 h-4 text-primary" />
                      )}
                    </button>
                  ))}
                </div>
              </ScrollArea>
            </Card>
          </motion.div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-8"
      >
        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Globe className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl mb-2">
          {currentTranslations.select_language || translate('select_language', selectedLanguage)}
        </h2>
        <p className="text-muted-foreground">
          {currentTranslations.choose_language || translate('choose_language', selectedLanguage)}
        </p>
      </motion.div>

      {/* Search */}
      <div className="mb-6">
        <input
          type="text"
          placeholder="Search languages..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Language Grid */}
      <ScrollArea className="max-h-96 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredLanguages.map((language, index) => (
            <motion.button
              key={language.code}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={() => handleLanguageSelect(language.code)}
              className={`p-4 rounded-lg border-2 transition-all text-left ${
                selectedLanguage === language.code
                  ? 'border-blue-500 bg-blue-50 dark:bg-blue-950'
                  : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50 dark:border-gray-700 dark:hover:border-gray-600 dark:hover:bg-gray-800'
              }`}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{language.flag}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-medium">{language.nativeName}</div>
                  <div className="text-sm text-muted-foreground">{language.name}</div>
                </div>
                {selectedLanguage === language.code && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center"
                  >
                    <Check className="w-4 h-4 text-white" />
                  </motion.div>
                )}
              </div>
            </motion.button>
          ))}
        </div>
      </ScrollArea>

      {/* Selected Language Display */}
      {selectedLang && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mb-6 p-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-lg border border-blue-200 dark:border-blue-800"
        >
          <div className="flex items-center gap-3">
            <span className="text-3xl">{selectedLang.flag}</span>
            <div>
              <div className="font-medium">
                {currentTranslations.language_selected || translate('language_selected', selectedLanguage)}: {selectedLang.nativeName}
              </div>
              <div className="text-sm text-muted-foreground">{selectedLang.name}</div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Confirm Button */}
      {showConfirmButton && onConfirm && selectedLang && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <Button
            onClick={onConfirm}
            size="lg"
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8"
          >
            {currentTranslations.continue || translate('continue', selectedLanguage)}
          </Button>
        </motion.div>
      )}
    </div>
  );
}