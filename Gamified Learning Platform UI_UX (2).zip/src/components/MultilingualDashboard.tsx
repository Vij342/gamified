import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Card, CardContent } from "./ui/card";
import { LanguageSelector } from "./LanguageSelector";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { multilingualDB, initializeSampleData } from "../utils/multilingualStorage";
import { translate, getLanguageByCode, SUPPORTED_LANGUAGES } from "../utils/languages";
import { 
  BookOpen, 
  Brain, 
  Calculator, 
  Globe, 
  Microscope, 
  Palette,
  Play,
  Star,
  Clock,
  Users,
  TrendingUp,
  Languages,
  ChevronRight,
  ArrowLeft
} from "lucide-react";

interface Subject {
  id: string;
  name: string;
  icon: any;
  color: string;
  progress: number;
  totalQuizzes: number;
  completedQuizzes: number;
  description: string;
}

interface MultilingualDashboardProps {
  onStartQuiz: (subjectId: string) => void;
  onViewLeaderboard: () => void;
  onViewAchievements: () => void;
  onViewProgress?: () => void;
  onBack?: () => void;
  defaultLanguage?: string;
}

export function MultilingualDashboard({ 
  onStartQuiz, 
  onViewLeaderboard, 
  onViewAchievements, 
  onViewProgress,
  onBack,
  defaultLanguage = 'en' 
}: MultilingualDashboardProps) {
  const [currentLanguage, setCurrentLanguage] = useState(defaultLanguage);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [availableLanguages, setAvailableLanguages] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [quizProgress, setQuizProgress] = useState<Record<string, any>>({});

  const selectedLang = getLanguageByCode(currentLanguage);

  const subjects: Subject[] = [
    {
      id: "mathematics",
      name: translate("mathematics", currentLanguage),
      icon: Calculator,
      color: "bg-blue-500",
      progress: quizProgress.mathematics?.progress || 0,
      totalQuizzes: 24,
      completedQuizzes: quizProgress.mathematics?.completed || 0,
      description: "Master numbers, equations, and problem-solving"
    },
    {
      id: "science",
      name: translate("science", currentLanguage),
      icon: Microscope,
      color: "bg-green-500",
      progress: quizProgress.science?.progress || 0,
      totalQuizzes: 20,
      completedQuizzes: quizProgress.science?.completed || 0,
      description: "Explore the natural world and scientific principles"
    },
    {
      id: "english",
      name: translate("english", currentLanguage),
      icon: BookOpen,
      color: "bg-purple-500",
      progress: quizProgress.english?.progress || 0,
      totalQuizzes: 18,
      completedQuizzes: quizProgress.english?.completed || 0,
      description: "Improve language skills and communication"
    },
    {
      id: "geography",
      name: translate("geography", currentLanguage),
      icon: Globe,
      color: "bg-orange-500",
      progress: quizProgress.geography?.progress || 0,
      totalQuizzes: 15,
      completedQuizzes: quizProgress.geography?.completed || 0,
      description: "Discover countries, capitals, and natural features"
    },
    {
      id: "history",
      name: translate("history", currentLanguage),
      icon: BookOpen,
      color: "bg-red-500",
      progress: quizProgress.history?.progress || 0,
      totalQuizzes: 16,
      completedQuizzes: quizProgress.history?.completed || 0,
      description: "Learn about past events and civilizations"
    },
    {
      id: "art",
      name: translate("art", currentLanguage),
      icon: Palette,
      color: "bg-pink-500",
      progress: quizProgress.art?.progress || 0,
      totalQuizzes: 12,
      completedQuizzes: quizProgress.art?.completed || 0,
      description: "Explore creativity, culture, and artistic expression"
    }
  ];

  useEffect(() => {
    initializeData();
  }, [currentLanguage]);

  const initializeData = async () => {
    try {
      setLoading(true);
      await initializeSampleData();
      
      // Get available languages for quizzes
      const languages = await multilingualDB.getAllAvailableLanguages();
      setAvailableLanguages(languages);
      
      // Load quiz progress for current language
      const userId = 'user-' + Date.now(); // In real app, use actual user ID
      const progress: Record<string, any> = {};
      
      for (const subject of subjects) {
        try {
          const results = await multilingualDB.getQuizResultsByLanguage(userId, currentLanguage);
          const subjectResults = results.filter(r => r.subject === subject.id);
          progress[subject.id] = {
            completed: subjectResults.length,
            progress: Math.min((subjectResults.length / subject.totalQuizzes) * 100, 100)
          };
        } catch (error) {
          console.error(`Failed to load progress for ${subject.id}:`, error);
          progress[subject.id] = { completed: 0, progress: 0 };
        }
      }
      
      setQuizProgress(progress);
    } catch (error) {
      console.error('Failed to initialize dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLanguageChange = (languageCode: string) => {
    setCurrentLanguage(languageCode);
    // Save user language preference
    const userId = 'user-' + Date.now(); // In real app, use actual user ID
    multilingualDB.saveUserLanguagePreference(userId, languageCode).catch(console.error);
  };

  const getLanguageAvailabilityBadge = (subjectId: string) => {
    const subjectLanguages = availableLanguages.filter(lang => 
      SUPPORTED_LANGUAGES.some(sl => sl.code === lang)
    );
    
    if (subjectLanguages.includes(currentLanguage)) {
      return (
        <Badge variant="secondary" className="text-xs">
          <Languages className="w-3 h-3 mr-1" />
          {selectedLang?.nativeName}
        </Badge>
      );
    } else {
      return (
        <Badge variant="outline" className="text-xs">
          <Languages className="w-3 h-3 mr-1" />
          English Only
        </Badge>
      );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg">{translate('loading', currentLanguage)}</p>
        </motion.div>
      </div>
    );
  }

  if (showLanguageSelector) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button variant="outline" onClick={() => setShowLanguageSelector(false)}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              {translate('back', currentLanguage)}
            </Button>
          </div>
          
          <LanguageSelector
            selectedLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            onConfirm={() => setShowLanguageSelector(false)}
            showConfirmButton={true}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          {onBack && (
            <Button variant="outline" onClick={onBack}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              {translate('back', currentLanguage)}
            </Button>
          )}
          
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center flex-1"
          >
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
              {translate('learn', currentLanguage)}
            </h1>
            <p className="text-muted-foreground">
              Choose a subject to start learning in {selectedLang?.nativeName}
            </p>
          </motion.div>

          <Button 
            variant="outline" 
            onClick={() => setShowLanguageSelector(true)}
            className="flex items-center gap-2"
          >
            <Globe className="w-4 h-4" />
            {selectedLang?.flag} {selectedLang?.nativeName}
          </Button>
        </div>

        {/* Language Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold mb-1">
                  {translate('language_selected', currentLanguage)}
                </h3>
                <p className="text-muted-foreground text-sm">
                  Learning in {selectedLang?.nativeName} • {availableLanguages.length} languages available
                </p>
              </div>
              <div className="flex items-center gap-2">
                {availableLanguages.slice(0, 6).map((langCode) => {
                  const lang = getLanguageByCode(langCode);
                  return (
                    <Button
                      key={langCode}
                      variant={langCode === currentLanguage ? "default" : "outline"}
                      size="sm"
                      onClick={() => handleLanguageChange(langCode)}
                      className="text-xs px-2"
                    >
                      {lang?.flag}
                    </Button>
                  );
                })}
                {availableLanguages.length > 6 && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowLanguageSelector(true)}
                    className="text-xs"
                  >
                    +{availableLanguages.length - 6}
                  </Button>
                )}
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow" onClick={onViewProgress}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium">{translate('progress', currentLanguage)}</h3>
                  <p className="text-sm text-muted-foreground">Track your learning</p>
                </div>
                <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground" />
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow" onClick={onViewAchievements}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <Star className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium">{translate('achievements', currentLanguage)}</h3>
                  <p className="text-sm text-muted-foreground">View your badges</p>
                </div>
                <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground" />
              </div>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow" onClick={onViewLeaderboard}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-medium">{translate('leaderboard', currentLanguage)}</h3>
                  <p className="text-sm text-muted-foreground">Compare with others</p>
                </div>
                <ChevronRight className="w-4 h-4 ml-auto text-muted-foreground" />
              </div>
            </Card>
          </motion.div>
        </div>

        {/* Subjects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject, index) => (
            <motion.div
              key={subject.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="group"
            >
              <Card className="p-6 h-full hover:shadow-lg transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-blue-200 dark:hover:border-blue-800">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-xl ${subject.color} flex items-center justify-center text-white group-hover:scale-110 transition-transform`}>
                    <subject.icon className="w-6 h-6" />
                  </div>
                  {getLanguageAvailabilityBadge(subject.id)}
                </div>

                <h3 className="text-lg font-semibold mb-2 group-hover:text-blue-600 transition-colors">
                  {subject.name}
                </h3>
                
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {subject.description}
                </p>

                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span>{translate('progress', currentLanguage)}</span>
                      <span>{Math.round(subject.progress)}%</span>
                    </div>
                    <Progress value={subject.progress} className="h-2" />
                  </div>

                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>{subject.completedQuizzes}/{subject.totalQuizzes} quizzes</span>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>~5 min</span>
                    </div>
                  </div>

                  <Button 
                    onClick={() => onStartQuiz(subject.id)}
                    className="w-full group-hover:bg-blue-600 group-hover:text-white transition-colors"
                    variant="outline"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    {translate('start_quiz', currentLanguage)}
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Interactive Quiz Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-8"
        >
          <Card className="p-6 bg-gradient-to-r from-purple-500 to-pink-500 text-white">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold mb-2">Interactive Voice Quiz</h3>
                <p className="opacity-90 mb-4">
                  Practice speaking and listening in {selectedLang?.nativeName}
                </p>
                <Button 
                  onClick={() => onStartQuiz('interactiveQuiz')}
                  variant="secondary"
                  className="bg-white text-purple-600 hover:bg-gray-100"
                >
                  <Brain className="w-4 h-4 mr-2" />
                  Try Interactive Quiz
                </Button>
              </div>
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <Brain className="w-10 h-10" />
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}