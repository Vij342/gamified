import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  Trophy, 
  Star, 
  Target, 
  Flame, 
  Crown, 
  Zap, 
  BookOpen, 
  Brain,
  ArrowLeft,
  Award,
  Medal,
  Shield,
  Rocket
} from "lucide-react";
import { motion } from "motion/react";

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: any;
  color: string;
  bgColor: string;
  progress: number;
  maxProgress: number;
  unlocked: boolean;
  category: "learning" | "streak" | "accuracy" | "speed" | "special";
  xpReward: number;
}

interface AchievementsProps {
  onBack: () => void;
}

const achievements: Achievement[] = [
  {
    id: "first_quiz",
    name: "First Steps",
    description: "Complete your first quiz",
    icon: BookOpen,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
    progress: 0,
    maxProgress: 1,
    unlocked: false,
    category: "learning",
    xpReward: 50
  },
  {
    id: "perfect_score",
    name: "Perfectionist",
    description: "Get 100% on any quiz",
    icon: Trophy,
    color: "text-yellow-600",
    bgColor: "bg-yellow-50",
    progress: 0,
    maxProgress: 3,
    unlocked: false,
    category: "accuracy",
    xpReward: 100
  },
  {
    id: "speed_demon",
    name: "Speed Demon",
    description: "Answer 10 questions in under 5 seconds each",
    icon: Rocket,
    color: "text-red-600",
    bgColor: "bg-red-50",
    progress: 0,
    maxProgress: 10,
    unlocked: false,
    category: "speed",
    xpReward: 150
  },
  {
    id: "streak_master",
    name: "Streak Master",
    description: "Maintain a 7-day learning streak",
    icon: Flame,
    color: "text-orange-600",
    bgColor: "bg-orange-50",
    progress: 0,
    maxProgress: 7,
    unlocked: false,
    category: "streak",
    xpReward: 200
  },
  {
    id: "quiz_master",
    name: "Quiz Master",
    description: "Complete 50 quizzes",
    icon: Crown,
    color: "text-purple-600",
    bgColor: "bg-purple-50",
    progress: 0,
    maxProgress: 50,
    unlocked: false,
    category: "learning",
    xpReward: 300
  },
  {
    id: "accuracy_expert",
    name: "Accuracy Expert",
    description: "Maintain 90%+ accuracy for 20 quizzes",
    icon: Target,
    color: "text-green-600",
    bgColor: "bg-green-50",
    progress: 0,
    maxProgress: 20,
    unlocked: false,
    category: "accuracy",
    xpReward: 250
  },
  {
    id: "knowledge_collector",
    name: "Knowledge Collector",
    description: "Complete quizzes in all 6 subjects",
    icon: Brain,
    color: "text-indigo-600",
    bgColor: "bg-indigo-50",
    progress: 0,
    maxProgress: 6,
    unlocked: false,
    category: "learning",
    xpReward: 400
  },
  {
    id: "lightning_learner",
    name: "Lightning Learner",
    description: "Complete a quiz in under 2 minutes",
    icon: Zap,
    color: "text-yellow-500",
    bgColor: "bg-yellow-50",
    progress: 0,
    maxProgress: 1,
    unlocked: false,
    category: "speed",
    xpReward: 120
  },
  {
    id: "dedicated_student",
    name: "Dedicated Student",
    description: "Study for 30 days straight",
    icon: Medal,
    color: "text-rose-600",
    bgColor: "bg-rose-50",
    progress: 0,
    maxProgress: 30,
    unlocked: false,
    category: "streak",
    xpReward: 500
  },
  {
    id: "champion",
    name: "Champion",
    description: "Reach the top of the leaderboard",
    icon: Shield,
    color: "text-emerald-600",
    bgColor: "bg-emerald-50",
    progress: 0,
    maxProgress: 1,
    unlocked: false,
    category: "special",
    xpReward: 1000
  }
];

const categories = [
  { id: "all", name: "All", count: achievements.length },
  { id: "learning", name: "Learning", count: achievements.filter(a => a.category === "learning").length },
  { id: "streak", name: "Streak", count: achievements.filter(a => a.category === "streak").length },
  { id: "accuracy", name: "Accuracy", count: achievements.filter(a => a.category === "accuracy").length },
  { id: "speed", name: "Speed", count: achievements.filter(a => a.category === "speed").length },
  { id: "special", name: "Special", count: achievements.filter(a => a.category === "special").length }
];

export function Achievements({ onBack }: AchievementsProps) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const unlockedCount = achievements.filter(a => a.unlocked).length;
  const totalXP = achievements.filter(a => a.unlocked).reduce((sum, a) => sum + a.xpReward, 0);

  const filteredAchievements = selectedCategory === "all" 
    ? achievements 
    : achievements.filter(a => a.category === selectedCategory);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        
        <div className="flex items-center gap-4">
          <div className="text-center p-3 bg-gradient-to-r from-yellow-400 to-orange-400 text-white rounded-lg">
            <div className="text-2xl font-bold">{unlockedCount}</div>
            <div className="text-xs">Unlocked</div>
          </div>
          <div className="text-center p-3 bg-gradient-to-r from-purple-400 to-pink-400 text-white rounded-lg">
            <div className="text-2xl font-bold">{totalXP}</div>
            <div className="text-xs">Total XP</div>
          </div>
        </div>
      </div>

      {/* Title */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
          Your Achievements
        </h1>
        <p className="text-muted-foreground">
          Unlock achievements by completing quizzes and reaching milestones
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {categories.map((category) => (
          <Button
            key={category.id}
            variant={selectedCategory === category.id ? "default" : "outline"}
            onClick={() => setSelectedCategory(category.id)}
            className="flex items-center gap-2"
          >
            {category.name}
            <Badge variant="secondary" className="ml-1">
              {category.count}
            </Badge>
          </Button>
        ))}
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAchievements.map((achievement, index) => {
          const IconComponent = achievement.icon;
          const progressPercentage = (achievement.progress / achievement.maxProgress) * 100;
          
          return (
            <motion.div
              key={achievement.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <Card className={`h-full transition-all duration-300 hover:shadow-lg hover:-translate-y-1 ${
                achievement.unlocked 
                  ? "border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-orange-50" 
                  : "bg-muted/30"
              }`}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className={`p-3 rounded-full ${
                      achievement.unlocked 
                        ? achievement.bgColor 
                        : "bg-muted"
                    } ${achievement.unlocked ? achievement.color : "text-muted-foreground"}`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    
                    {achievement.unlocked && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", delay: 0.3 }}
                      >
                        <Trophy className="h-5 w-5 text-yellow-500" />
                      </motion.div>
                    )}
                  </div>
                  
                  <CardTitle className={`text-lg ${
                    achievement.unlocked ? "text-foreground" : "text-muted-foreground"
                  }`}>
                    {achievement.name}
                  </CardTitle>
                </CardHeader>
                
                <CardContent>
                  <p className={`text-sm mb-4 ${
                    achievement.unlocked ? "text-muted-foreground" : "text-muted-foreground/60"
                  }`}>
                    {achievement.description}
                  </p>
                  
                  {!achievement.unlocked && (
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{achievement.progress}/{achievement.maxProgress}</span>
                      </div>
                      <Progress value={progressPercentage} className="h-2" />
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <Badge className={`${
                      achievement.unlocked 
                        ? "bg-green-100 text-green-800" 
                        : "bg-muted text-muted-foreground"
                    }`}>
                      {achievement.unlocked ? "Unlocked" : "Locked"}
                    </Badge>
                    
                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                      <Zap className="h-3 w-3" />
                      +{achievement.xpReward} XP
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filteredAchievements.length === 0 && (
        <div className="text-center py-12">
          <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-muted-foreground mb-2">
            No achievements found
          </h3>
          <p className="text-muted-foreground">
            Try selecting a different category
          </p>
        </div>
      )}
    </div>
  );
}