import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Trophy, Flame, Zap, Settings } from "lucide-react";
import { Button } from "./ui/button";
import { Navigation } from "./Navigation";

type AppState = "home" | "dashboard" | "multilingualDashboard" | "quiz" | "results" | "achievements" | "leaderboard" | "teacher" | "family" | "help" | "contact";

interface HeaderProps {
  user: {
    name: string;
    avatar: string;
    level: number;
    xp: number;
    xpToNext: number;
    streak: number;
    coins: number;
  };
  currentState: AppState;
  onNavigate: (state: AppState) => void;
  onSettingsClick: () => void;
}

export function Header({ user, currentState, onNavigate, onSettingsClick }: HeaderProps) {
  const xpProgress = user.xpToNext > 0 ? (user.xp / user.xpToNext) * 100 : 0;

  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 shadow-lg relative">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => onNavigate("home")}
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
          >
            <Zap className="h-8 w-8 text-yellow-300" />
            <h1 className="text-2xl font-bold">EduSpark</h1>
          </button>
        </div>

        {/* Navigation */}
        <Navigation currentState={currentState} onNavigate={onNavigate} />

        <div className="flex items-center space-x-6">
          {/* XP Progress */}
          <div className="flex items-center space-x-3">
            <div className="flex flex-col">
              <div className="flex items-center space-x-2 mb-1">
                <Badge variant="secondary" className="bg-yellow-500 text-black">
                  Level {user.level}
                </Badge>
                <span className="text-sm">{user.xp}/100 XP</span>
              </div>
              <Progress value={xpProgress} className="w-32 h-2" />
            </div>
          </div>

          {/* Stats */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Flame className="h-5 w-5 text-orange-400" />
              <span className="font-medium">{user.streak}</span>
            </div>
            
            <div className="flex items-center space-x-1">
              <Trophy className="h-5 w-5 text-yellow-400" />
              <span className="font-medium">{user.coins}</span>
            </div>
          </div>

          {/* User Profile */}
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={user.avatar} />
              <AvatarFallback>{user.name.slice(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="hidden md:block">
              <p className="font-medium">{user.name}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onSettingsClick}
              className="text-white hover:bg-white/20"
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}