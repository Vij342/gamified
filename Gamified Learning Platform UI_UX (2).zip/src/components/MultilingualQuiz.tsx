import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Clock, Volume2, Mic, MicOff, Globe, Check, X } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { LanguageSelector } from "./LanguageSelector";
import { multilingualDB, initializeSampleData } from "../utils/multilingualStorage";
import { translate, getLanguageByCode, isRTLLanguage } from "../utils/languages";

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  subject: string;
  language: string;
}

interface MultilingualQuizProps {
  subject: string;
  onBack: () => void;
  onComplete: (score: number, xpEarned: number) => void;
  defaultLanguage?: string;
}

export function MultilingualQuiz({ subject, onBack, onComplete, defaultLanguage = 'en' }: MultilingualQuizProps) {
  const [currentLanguage, setCurrentLanguage] = useState(defaultLanguage);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isListening, setIsListening] = useState(false);
  const [speechRecognition, setSpeechRecognition] = useState<any>(null);

  const currentQuestion = questions[currentQuestionIndex];
  const isRTL = isRTLLanguage(currentLanguage);
  const selectedLang = getLanguageByCode(currentLanguage);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = currentLanguage === 'hi' ? 'hi-IN' : currentLanguage === 'es' ? 'es-ES' : 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript.toLowerCase();
        console.log('Voice input:', transcript);
        
        // Try to match voice input with answer options
        if (currentQuestion) {
          currentQuestion.options.forEach((option, index) => {
            if (transcript.includes(option.toLowerCase()) || 
                transcript.includes((index + 1).toString()) ||
                transcript.includes(['first', 'second', 'third', 'fourth'][index])) {
              setSelectedAnswer(index);
            }
          });
        }
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      setSpeechRecognition(recognition);
    }
  }, [currentLanguage, currentQuestion]);

  // Load questions when language changes
  useEffect(() => {
    loadQuestions();
  }, [currentLanguage, subject]);

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTimerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(time => {
          if (time <= 1) {
            handleNextQuestion();
            return 30;
          }
          return time - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerActive, timeLeft]);

  const loadQuestions = async () => {
    try {
      setLoading(true);
      await initializeSampleData(); // Initialize if needed
      const loadedQuestions = await multilingualDB.getQuizQuestions(subject, currentLanguage);
      
      if (loadedQuestions.length === 0) {
        // Fallback to English if no questions in selected language
        const englishQuestions = await multilingualDB.getQuizQuestions(subject, 'en');
        setQuestions(englishQuestions);
      } else {
        setQuestions(loadedQuestions);
      }
      
      setCurrentQuestionIndex(0);
      setSelectedAnswer(null);
      setUserAnswers([]);
      setScore(0);
      setTimeLeft(30);
      setIsTimerActive(true);
    } catch (error) {
      console.error('Failed to load questions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer !== null) {
      const newAnswers = [...userAnswers, selectedAnswer];
      setUserAnswers(newAnswers);
      
      if (selectedAnswer === currentQuestion.correctAnswer) {
        setScore(score + 1);
      }
    } else {
      setUserAnswers([...userAnswers, -1]); // -1 for no answer/timeout
    }

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setTimeLeft(30);
    } else {
      completeQuiz();
    }
  };

  const completeQuiz = async () => {
    setIsTimerActive(false);
    const finalScore = selectedAnswer === currentQuestion?.correctAnswer ? score + 1 : score;
    const xpEarned = Math.round((finalScore / questions.length) * 100);
    
    // Save quiz result with language info
    try {
      await multilingualDB.saveQuizResult(
        'user-' + Date.now(), // In real app, use actual user ID
        subject,
        currentLanguage,
        finalScore,
        questions.length,
        userAnswers
      );
    } catch (error) {
      console.error('Failed to save quiz result:', error);
    }

    setShowResults(true);
    onComplete(finalScore, xpEarned);
  };

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = currentLanguage === 'hi' ? 'hi-IN' : currentLanguage === 'es' ? 'es-ES' : 'en-US';
      utterance.rate = 0.8;
      speechSynthesis.speak(utterance);
    }
  };

  const startListening = () => {
    if (speechRecognition && !isListening) {
      setIsListening(true);
      speechRecognition.start();
    }
  };

  const stopListening = () => {
    if (speechRecognition && isListening) {
      speechRecognition.stop();
      setIsListening(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center"
        >
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg">{translate('loading', currentLanguage)}</p>
        </motion.div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md mx-auto p-6"
        >
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <X className="w-8 h-8 text-red-500" />
          </div>
          <h2 className="text-xl mb-2">No questions available</h2>
          <p className="text-muted-foreground mb-4">
            Questions for {subject} in {selectedLang?.nativeName} are not available yet.
          </p>
          <Button onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Go Back
          </Button>
        </motion.div>
      </div>
    );
  }

  if (showLanguageSelector) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <Button variant="outline" onClick={() => setShowLanguageSelector(false)}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              {translate('back', currentLanguage)}
            </Button>
          </div>
          
          <LanguageSelector
            selectedLanguage={currentLanguage}
            onLanguageChange={setCurrentLanguage}
            onConfirm={() => setShowLanguageSelector(false)}
            showConfirmButton={true}
          />
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 p-4 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            {translate('back', currentLanguage)}
          </Button>
          
          <div className="flex items-center gap-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowLanguageSelector(true)}
              className="flex items-center gap-2"
            >
              <Globe className="w-4 h-4" />
              {selectedLang?.flag} {selectedLang?.nativeName}
            </Button>
            
            <div className="flex items-center gap-2 text-sm">
              <Clock className="w-4 h-4" />
              <span className={timeLeft <= 10 ? 'text-red-500 font-bold' : ''}>{timeLeft}s</span>
            </div>
          </div>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">
              {translate('question', currentLanguage)} {currentQuestionIndex + 1} / {questions.length}
            </span>
            <Badge variant="secondary">
              {currentQuestion?.difficulty}
            </Badge>
          </div>
          <Progress value={((currentQuestionIndex + 1) / questions.length) * 100} className="h-2" />
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIndex}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="p-8 mb-6">
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold">
                    {currentQuestion?.question}
                  </h2>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => speakText(currentQuestion?.question || '')}
                    >
                      <Volume2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={isListening ? "destructive" : "outline"}
                      size="sm"
                      onClick={isListening ? stopListening : startListening}
                      disabled={!speechRecognition}
                    >
                      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                {isListening && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg mb-4"
                  >
                    <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                      <span className="text-sm">Listening for your answer...</span>
                    </div>
                  </motion.div>
                )}
              </div>

              <div className="space-y-3">
                {currentQuestion?.options.map((option, index) => (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleAnswerSelect(index)}
                    className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                      selectedAnswer === index
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50 dark:border-gray-700 dark:hover:border-gray-600 dark:hover:bg-gray-800'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                        selectedAnswer === index
                          ? 'border-blue-500 bg-blue-500'
                          : 'border-gray-300'
                      }`}>
                        {selectedAnswer === index && (
                          <Check className="w-4 h-4 text-white" />
                        )}
                      </div>
                      <span className="flex-1">{option}</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          speakText(option);
                        }}
                      >
                        <Volume2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </motion.button>
                ))}
              </div>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Next Button */}
        <div className="text-center">
          <Button
            onClick={handleNextQuestion}
            size="lg"
            disabled={selectedAnswer === null}
            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8"
          >
            {currentQuestionIndex === questions.length - 1 
              ? translate('finish', currentLanguage)
              : translate('next_question', currentLanguage)
            }
          </Button>
        </div>
      </div>
    </div>
  );
}