import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Zap, 
  BookOpen, 
  Users, 
  Trophy, 
  Star, 
  Play, 
  UserCheck,
  ArrowRight,
  CheckCircle,
  Sparkles,
  Target,
  Gamepad2,
  Globe,
  Languages
} from "lucide-react";
import { motion } from "motion/react";

interface HomePageProps {
  onNavigate: (state: "dashboard" | "teacher" | "family" | "help") => void;
}

const features = [
  {
    icon: Gamepad2,
    title: "Gamified Learning",
    description: "Turn studying into an exciting adventure with points, levels, and achievements.",
    color: "bg-blue-500"
  },
  {
    icon: Trophy,
    title: "Competitive Leaderboards", 
    description: "Compete with friends and classmates to reach the top of the rankings.",
    color: "bg-yellow-500"
  },
  {
    icon: UserCheck,
    title: "Teacher Dashboard",
    description: "Educators can track student progress and assign custom quizzes.",
    color: "bg-green-500"
  },
  {
    icon: Users,
    title: "Family Insights",
    description: "Parents can monitor their children's learning journey and celebrate achievements.",
    color: "bg-purple-500"
  },
  {
    icon: BookOpen,
    title: "Multiple Subjects",
    description: "Master Mathematics, Science, English, Geography, History, and Arts.",
    color: "bg-red-500"
  },
  {
    icon: Sparkles,
    title: "Offline Learning",
    description: "Continue learning even without internet connection with our offline quiz mode.",
    color: "bg-orange-500"
  }
];

const testimonials = [
  {
    name: "Sarah Johnson",
    role: "Grade 8 Student",
    content: "EduSpark made math fun for me! I love earning XP and competing with my friends.",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b2292bb9?w=150&h=150&fit=crop&crop=face"
  },
  {
    name: "Ms. Rodriguez",
    role: "Mathematics Teacher",
    content: "The teacher dashboard helps me track my students' progress and identify areas for improvement.",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
  },
  {
    name: "David Chen",
    role: "Parent",
    content: "I love seeing my daughter's learning journey through the family tracking feature. Very motivating!",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
  }
];

export function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <div className="flex items-center gap-2 mb-6">
                <Badge className="bg-yellow-500 text-black px-4 py-2">
                  🔥 New: Offline Quiz Mode Available!
                </Badge>
              </div>
              
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Spark Your Learning
                <span className="block bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                  Adventure
                </span>
              </h1>
              
              <p className="text-xl mb-8 opacity-90 leading-relaxed">
                Transform education into an exciting journey with gamified quizzes, 
                progress tracking, and competitive learning. Perfect for students, 
                teachers, and families!
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => onNavigate("dashboard")}
                  className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4"
                >
                  <Play className="mr-2 h-5 w-5" />
                  Start Learning Now
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  onClick={() => onNavigate("help")}
                  className="border-white text-white hover:bg-white/10 px-8 py-4"
                >
                  Learn More
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <div className="relative z-10">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1696087225391-eb97abf5ba20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkeSUyMGRlc2slMjB3b3Jrc3BhY2UlMjBtb2Rlcm58ZW58MXx8fHwxNzU3Nzc3OTg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Modern learning workspace"
                  className="w-full h-96 object-cover rounded-2xl shadow-2xl"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-blue-600/20 to-transparent rounded-2xl"></div>
              
              {/* Floating Elements */}
              <motion.div
                animate={{ y: [-10, 10, -10] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -top-4 -right-4 bg-yellow-400 text-black p-3 rounded-full shadow-lg"
              >
                <Trophy className="h-6 w-6" />
              </motion.div>
              
              <motion.div
                animate={{ y: [10, -10, 10] }}
                transition={{ duration: 3, repeat: Infinity, delay: 1 }}
                className="absolute -bottom-4 -left-4 bg-green-400 text-white p-3 rounded-full shadow-lg"
              >
                <Star className="h-6 w-6" />
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Why Choose EduSpark?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              We combine cutting-edge gamification with proven educational methods to create 
              an engaging learning experience for students of all ages.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                    <CardHeader>
                      <div className={`${feature.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle className="text-xl">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <div className="text-4xl font-bold mb-2">10,000+</div>
              <div className="text-lg opacity-90">Active Students</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="text-4xl font-bold mb-2">500+</div>
              <div className="text-lg opacity-90">Teachers</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="text-4xl font-bold mb-2">50,000+</div>
              <div className="text-lg opacity-90">Quizzes Completed</div>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="text-4xl font-bold mb-2">95%</div>
              <div className="text-lg opacity-90">Satisfaction Rate</div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">What Our Users Say</h2>
            <p className="text-xl text-muted-foreground">
              Hear from students, teachers, and parents who've transformed their learning experience.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
              >
                <Card className="h-full">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4 mb-4">
                      <ImageWithFallback
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <h4 className="font-semibold">{testimonial.name}</h4>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground italic">"{testimonial.content}"</p>
                    <div className="flex text-yellow-400 mt-4">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-current" />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-4xl font-bold mb-6">
              Ready to Transform Your Learning Experience?
            </h2>
            <p className="text-xl mb-8 opacity-90">
              Join thousands of students, teachers, and families who are already 
              sparking their educational journey with EduSpark.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                onClick={() => onNavigate("dashboard")}
                className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4"
              >
                <Zap className="mr-2 h-5 w-5" />
                Start Your Journey
              </Button>
              <Button 
                size="lg" 
                onClick={() => onNavigate("teacher")}
                variant="outline" 
                className="border-white text-white hover:bg-white/10 px-8 py-4"
              >
                <UserCheck className="mr-2 h-5 w-5" />
                For Educators
              </Button>
              <Button 
                size="lg" 
                onClick={() => onNavigate("family")}
                variant="outline" 
                className="border-white text-white hover:bg-white/10 px-8 py-4"
              >
                <Users className="mr-2 h-5 w-5" />
                For Families
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}