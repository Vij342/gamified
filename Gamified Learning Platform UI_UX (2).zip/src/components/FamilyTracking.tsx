import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Users, 
  Heart, 
  Trophy, 
  Star, 
  Target, 
  Clock, 
  TrendingUp,
  Calendar,
  Gift,
  Award,
  Flame,
  BookOpen,
  CheckCircle,
  AlertCircle,
  Zap
} from "lucide-react";
import { motion } from "motion/react";

interface FamilyMember {
  id: string;
  name: string;
  avatar: string;
  relationship: string;
  level: number;
  xp: number;
  accuracy: number;
  streak: number;
  favoriteSubject: string;
  weeklyGoal: number;
  weeklyProgress: number;
  recentAchievements: string[];
  needsEncouragement?: boolean;
}

interface FamilyTrackingProps {
  onBack: () => void;
}

const familyMembers: FamilyMember[] = [
  {
    id: "1",
    name: "Emma",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b2292bb9?w=150&h=150&fit=crop&crop=face",
    relationship: "Daughter",
    level: 12,
    xp: 2340,
    accuracy: 94,
    streak: 7,
    favoriteSubject: "Mathematics",
    weeklyGoal: 5,
    weeklyProgress: 4,
    recentAchievements: ["Perfect Score", "Math Master", "Week Streak"]
  },
  {
    id: "2",
    name: "Alex",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    relationship: "Son",
    level: 8,
    xp: 1420,
    accuracy: 76,
    streak: 2,
    favoriteSubject: "Science",
    weeklyGoal: 3,
    weeklyProgress: 1,
    recentAchievements: ["Science Explorer"],
    needsEncouragement: true
  },
  {
    id: "3",
    name: "Sarah (You)",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    relationship: "Parent",
    level: 0,
    xp: 0,
    accuracy: 0,
    streak: 0,
    favoriteSubject: "Not started",
    weeklyGoal: 2,
    weeklyProgress: 0,
    recentAchievements: []
  }
];

const familyStats = {
  totalXP: familyMembers.reduce((sum, member) => sum + member.xp, 0),
  averageAccuracy: Math.round(familyMembers.reduce((sum, member) => sum + member.accuracy, 0) / familyMembers.length),
  longestStreak: Math.max(...familyMembers.map(member => member.streak)),
  totalAchievements: familyMembers.reduce((sum, member) => sum + member.recentAchievements.length, 0)
};

const weeklySchedule = [
  { day: "Monday", planned: ["Emma - Math Quiz", "Alex - Science Reading"], completed: ["Emma - Math Quiz"] },
  { day: "Tuesday", planned: ["Sarah - History Quiz"], completed: ["Sarah - History Quiz"] },
  { day: "Wednesday", planned: ["Emma - English Quiz", "Alex - Math Practice"], completed: [] },
  { day: "Thursday", planned: ["Family Quiz Night"], completed: [] },
  { day: "Friday", planned: ["Emma - Science Lab", "Alex - Geography"], completed: [] }
];

const rewards = [
  { name: "Ice Cream Night", cost: 100, icon: "🍦", description: "Family ice cream outing" },
  { name: "Movie Night", cost: 150, icon: "🍿", description: "Choose any family movie" },
  { name: "Extra Screen Time", cost: 75, icon: "📱", description: "+30 minutes device time" },
  { name: "Pizza Party", cost: 200, icon: "🍕", description: "Order favorite pizza" },
  { name: "New Book", cost: 80, icon: "📚", description: "Choose a new book" },
  { name: "Weekend Trip", cost: 500, icon: "🎢", description: "Fun family day out" }
];

export function FamilyTracking({ onBack }: FamilyTrackingProps) {
  const [selectedTab, setSelectedTab] = useState("overview");
  const [familyXP] = useState(familyStats.totalXP);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Family Learning Hub
          </h1>
          <p className="text-muted-foreground mt-2">
            Track your family's learning journey together
          </p>
        </div>
        
        <Button onClick={onBack} variant="outline">
          <Users className="mr-2 h-4 w-4" />
          Back to Main
        </Button>
      </div>

      {/* Hero Section with Family Image */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl p-8 text-white mb-8 relative overflow-hidden">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">Learning Together! 👨‍👩‍👧‍👦</h2>
            <p className="text-lg opacity-90 mb-6">
              Your family has earned {familyXP.toLocaleString()} XP together this month! 
              Keep up the amazing work and support each other's learning journey.
            </p>
            <div className="flex gap-4">
              <Button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm">
                <Gift className="mr-2 h-4 w-4" />
                Family Rewards
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm">
                <Calendar className="mr-2 h-4 w-4" />
                Study Schedule
              </Button>
            </div>
          </div>
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1476703993599-0035a21b17a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBsZWFybmluZyUyMHRvZ2V0aGVyJTIwaG9tZXxlbnwxfHx8fDE3NTc3NzgzNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Family learning together"
              className="w-full h-64 object-cover rounded-lg opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-600/40 to-transparent rounded-lg"></div>
          </div>
        </div>
      </div>

      {/* Family Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-4 text-center">
            <Zap className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{familyStats.totalXP.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">Family XP</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{familyStats.averageAccuracy}%</div>
            <div className="text-sm text-muted-foreground">Avg Accuracy</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Flame className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{familyStats.longestStreak}</div>
            <div className="text-sm text-muted-foreground">Best Streak</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{familyStats.totalAchievements}</div>
            <div className="text-sm text-muted-foreground">Achievements</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="members">Family Members</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="rewards">Rewards</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Family Progress */}
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  This Week's Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {familyMembers.map((member) => (
                    <div key={member.id} className="flex items-center gap-4 p-4 rounded-lg bg-muted/50">
                      <ImageWithFallback
                        src={member.avatar}
                        alt={member.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-medium">{member.name}</h4>
                          <Badge variant="secondary">{member.relationship}</Badge>
                          {member.needsEncouragement && (
                            <Badge className="bg-orange-100 text-orange-800">Needs Support</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>Weekly Goal: {member.weeklyProgress}/{member.weeklyGoal} quizzes</span>
                          <span>•</span>
                          <span>Streak: {member.streak} days</span>
                        </div>
                        <Progress 
                          value={(member.weeklyProgress / member.weeklyGoal) * 100} 
                          className="mt-2 h-2"
                        />
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-purple-600">{member.xp}</div>
                        <div className="text-xs text-muted-foreground">XP</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  Encouragement Corner
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="font-medium text-green-800">Emma is on fire! 🔥</span>
                    </div>
                    <p className="text-sm text-green-700">
                      7-day streak and 94% accuracy in Math. Amazing work!
                    </p>
                  </div>
                  
                  <div className="p-4 rounded-lg bg-orange-50 border border-orange-200">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertCircle className="h-4 w-4 text-orange-600" />
                      <span className="font-medium text-orange-800">Alex needs support</span>
                    </div>
                    <p className="text-sm text-orange-700">
                      Only 1/3 weekly quizzes done. Maybe try studying together?
                    </p>
                    <Button size="sm" className="mt-2 bg-orange-600 hover:bg-orange-700">
                      Send Encouragement
                    </Button>
                  </div>
                  
                  <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Star className="h-4 w-4 text-purple-600" />
                      <span className="font-medium text-purple-800">Family Goal</span>
                    </div>
                    <p className="text-sm text-purple-700">
                      Complete 10 family quizzes this month to unlock the weekend trip reward!
                    </p>
                    <Progress value={70} className="mt-2 h-2" />
                    <p className="text-xs text-purple-600 mt-1">7/10 completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5" />
                Recent Family Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {familyMembers.map((member) => (
                  <div key={member.id} className="space-y-3">
                    <div className="flex items-center gap-3">
                      <ImageWithFallback
                        src={member.avatar}
                        alt={member.name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <h4 className="font-medium">{member.name}</h4>
                    </div>
                    <div className="space-y-2">
                      {member.recentAchievements.map((achievement) => (
                        <Badge key={achievement} className="mr-2 bg-yellow-100 text-yellow-800">
                          🏆 {achievement}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="members" className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {familyMembers.map((member, index) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-all duration-300">
                  <CardHeader className="text-center">
                    <ImageWithFallback
                      src={member.avatar}
                      alt={member.name}
                      className="w-20 h-20 rounded-full object-cover mx-auto mb-4"
                    />
                    <CardTitle className="text-xl">{member.name}</CardTitle>
                    <Badge variant="secondary">{member.relationship}</Badge>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="text-center p-3 bg-muted/50 rounded-lg">
                          <div className="text-lg font-bold text-purple-600">{member.level}</div>
                          <div className="text-xs text-muted-foreground">Level</div>
                        </div>
                        <div className="text-center p-3 bg-muted/50 rounded-lg">
                          <div className="text-lg font-bold text-green-600">{member.accuracy}%</div>
                          <div className="text-xs text-muted-foreground">Accuracy</div>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Weekly Progress</p>
                        <Progress value={(member.weeklyProgress / member.weeklyGoal) * 100} className="h-2" />
                        <p className="text-xs text-muted-foreground mt-1">
                          {member.weeklyProgress}/{member.weeklyGoal} quizzes completed
                        </p>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm">
                        <span>Favorite Subject:</span>
                        <Badge>{member.favoriteSubject}</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm">
                        <span>Current Streak:</span>
                        <div className="flex items-center gap-1">
                          <Flame className="h-3 w-3 text-orange-500" />
                          <span className="font-medium">{member.streak} days</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Family Study Schedule
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {weeklySchedule.map((day) => (
                  <div key={day.day} className="border rounded-lg p-4">
                    <h3 className="font-semibold mb-3">{day.day}</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground mb-2">Planned Activities</h4>
                        <div className="space-y-1">
                          {day.planned.map((activity, index) => (
                            <div key={index} className="flex items-center gap-2 text-sm">
                              <Clock className="h-3 w-3 text-blue-500" />
                              {activity}
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-muted-foreground mb-2">Completed</h4>
                        <div className="space-y-1">
                          {day.completed.map((activity, index) => (
                            <div key={index} className="flex items-center gap-2 text-sm text-green-600">
                              <CheckCircle className="h-3 w-3" />
                              {activity}
                            </div>
                          ))}
                          {day.completed.length === 0 && (
                            <p className="text-sm text-muted-foreground">Nothing completed yet</p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rewards">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5" />
                Family Reward Store
              </CardTitle>
              <p className="text-muted-foreground">
                Current Family XP: <span className="font-bold text-purple-600">{familyXP.toLocaleString()}</span>
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {rewards.map((reward) => (
                  <div key={reward.name} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="text-center mb-3">
                      <div className="text-3xl mb-2">{reward.icon}</div>
                      <h3 className="font-semibold">{reward.name}</h3>
                      <p className="text-sm text-muted-foreground">{reward.description}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1">
                        <Zap className="h-4 w-4 text-purple-500" />
                        <span className="font-medium">{reward.cost} XP</span>
                      </div>
                      <Button 
                        size="sm" 
                        disabled={familyXP < reward.cost}
                        className={familyXP >= reward.cost ? "" : "opacity-50"}
                      >
                        {familyXP >= reward.cost ? "Redeem" : "Need More XP"}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}