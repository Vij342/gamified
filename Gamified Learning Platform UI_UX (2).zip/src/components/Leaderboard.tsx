import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ArrowLeft, Trophy, Medal, Award, Crown, Star, TrendingUp } from "lucide-react";
import { motion } from "motion/react";

interface LeaderboardEntry {
  id: string;
  name: string;
  avatar: string;
  level: number;
  xp: number;
  accuracy: number;
  quizzesCompleted: number;
  streak: number;
  isCurrentUser?: boolean;
}

interface LeaderboardProps {
  onBack: () => void;
}

const weeklyLeaderboard: LeaderboardEntry[] = [
  {
    id: "1",
    name: "Alex Johnson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    level: 15,
    xp: 2840,
    accuracy: 94,
    quizzesCompleted: 28,
    streak: 7
  },
  {
    id: "2", 
    name: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b2292bb9?w=150&h=150&fit=crop&crop=face",
    level: 14,
    xp: 2650,
    accuracy: 92,
    quizzesCompleted: 25,
    streak: 5
  },
  {
    id: "3",
    name: "Mike Rodriguez", 
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    level: 13,
    xp: 2420,
    accuracy: 89,
    quizzesCompleted: 24,
    streak: 4
  },
  {
    id: "4",
    name: "You",
    avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face",
    level: 0,
    xp: 0,
    accuracy: 0,
    quizzesCompleted: 0,
    streak: 0,
    isCurrentUser: true
  },
  {
    id: "5",
    name: "Emma Wilson",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    level: 11,
    xp: 1950,
    accuracy: 91,
    quizzesCompleted: 20,
    streak: 6
  },
  {
    id: "6",
    name: "David Kim",
    avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671d66?w=150&h=150&fit=crop&crop=face",
    level: 10,
    xp: 1720,
    accuracy: 85,
    quizzesCompleted: 19,
    streak: 2
  },
  {
    id: "7",
    name: "Lisa Park",
    avatar: "https://images.unsplash.com/photo-1504703395950-b89145a5425b?w=150&h=150&fit=crop&crop=face",
    level: 9,
    xp: 1580,
    accuracy: 88,
    quizzesCompleted: 18,
    streak: 1
  },
  {
    id: "8",
    name: "James Brown",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face", 
    level: 8,
    xp: 1420,
    accuracy: 83,
    quizzesCompleted: 17,
    streak: 0
  }
];

const monthlyLeaderboard: LeaderboardEntry[] = [
  ...weeklyLeaderboard.map(entry => ({
    ...entry,
    xp: entry.xp * 4,
    quizzesCompleted: entry.quizzesCompleted * 4
  }))
].sort((a, b) => b.xp - a.xp);

const allTimeLeaderboard: LeaderboardEntry[] = [
  ...weeklyLeaderboard.map(entry => ({
    ...entry,
    xp: entry.xp * 12,
    quizzesCompleted: entry.quizzesCompleted * 12,
    level: entry.level + 5
  }))
].sort((a, b) => b.xp - a.xp);

export function Leaderboard({ onBack }: LeaderboardProps) {
  const [selectedPeriod, setSelectedPeriod] = useState("weekly");

  const getLeaderboardData = () => {
    switch (selectedPeriod) {
      case "monthly": return monthlyLeaderboard;
      case "alltime": return allTimeLeaderboard;
      default: return weeklyLeaderboard;
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-6 w-6 text-yellow-500" />;
      case 2: return <Medal className="h-6 w-6 text-gray-400" />;
      case 3: return <Award className="h-6 w-6 text-amber-600" />;
      default: return <span className="text-lg font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1: return "bg-gradient-to-r from-yellow-400 to-yellow-600";
      case 2: return "bg-gradient-to-r from-gray-300 to-gray-500";
      case 3: return "bg-gradient-to-r from-amber-400 to-amber-600";
      default: return "bg-gradient-to-r from-blue-400 to-blue-600";
    }
  };

  const leaderboardData = getLeaderboardData();
  const currentUser = leaderboardData.find(entry => entry.isCurrentUser);
  const currentUserRank = leaderboardData.findIndex(entry => entry.isCurrentUser) + 1;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Button>
        
        {currentUser && (
          <div className="flex items-center gap-4 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
            <div className="text-center">
              <div className="text-lg font-bold text-primary">#{currentUserRank}</div>
              <div className="text-xs text-muted-foreground">Your Rank</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-green-600">{currentUser.xp}</div>
              <div className="text-xs text-muted-foreground">Your XP</div>
            </div>
          </div>
        )}
      </div>

      {/* Title */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
          Leaderboard
        </h1>
        <p className="text-muted-foreground">
          Compete with other learners and climb to the top!
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-8">
          <TabsTrigger value="weekly">This Week</TabsTrigger>
          <TabsTrigger value="monthly">This Month</TabsTrigger>
          <TabsTrigger value="alltime">All Time</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedPeriod}>
          {/* Top 3 Podium */}
          <div className="mb-8">
            <div className="flex justify-center items-end gap-4 mb-8">
              {leaderboardData.slice(0, 3).map((entry, index) => {
                const rank = index + 1;
                const heights = ["h-32", "h-40", "h-28"];
                const positions = [1, 0, 2]; // Second place in middle (tallest)
                const actualIndex = positions[index];
                const actualEntry = leaderboardData[actualIndex];
                const actualRank = actualIndex + 1;
                
                return (
                  <motion.div
                    key={actualEntry.id}
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: actualIndex * 0.2 }}
                    className="text-center"
                  >
                    <div className="mb-4">
                      <Avatar className="w-16 h-16 mx-auto mb-2 ring-4 ring-white shadow-lg">
                        <AvatarImage src={actualEntry.avatar} />
                        <AvatarFallback>{actualEntry.name.slice(0, 2)}</AvatarFallback>
                      </Avatar>
                      <h3 className="font-semibold">{actualEntry.name}</h3>
                      <p className="text-sm text-muted-foreground">{actualEntry.xp} XP</p>
                    </div>
                    
                    <div className={`${getRankBadgeColor(actualRank)} ${heights[actualIndex]} w-24 rounded-t-lg flex flex-col justify-between items-center p-4 text-white`}>
                      <div className="mb-2">
                        {getRankIcon(actualRank)}
                      </div>
                      <div className="text-xs font-medium">
                        Level {actualEntry.level}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Full Leaderboard */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-yellow-500" />
                Rankings
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-0">
                {leaderboardData.map((entry, index) => {
                  const rank = index + 1;
                  return (
                    <motion.div
                      key={entry.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className={`flex items-center justify-between p-4 border-b last:border-b-0 hover:bg-muted/50 transition-colors ${
                        entry.isCurrentUser ? "bg-blue-50 border-blue-200" : ""
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 flex justify-center">
                          {getRankIcon(rank)}
                        </div>
                        
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={entry.avatar} />
                          <AvatarFallback>{entry.name.slice(0, 2)}</AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className={`font-medium ${entry.isCurrentUser ? "text-blue-700" : ""}`}>
                              {entry.name}
                            </h4>
                            {entry.isCurrentUser && (
                              <Badge className="bg-blue-500">You</Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Level {entry.level} • {entry.quizzesCompleted} quizzes
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center gap-4">
                          <div className="text-center">
                            <div className="font-semibold">{entry.accuracy}%</div>
                            <div className="text-xs text-muted-foreground">Accuracy</div>
                          </div>
                          
                          <div className="text-center">
                            <div className="flex items-center gap-1">
                              <Star className="h-3 w-3 text-orange-500" />
                              <span className="font-semibold">{entry.streak}</span>
                            </div>
                            <div className="text-xs text-muted-foreground">Streak</div>
                          </div>
                          
                          <div className="text-center min-w-[60px]">
                            <div className="font-bold text-lg text-primary">{entry.xp}</div>
                            <div className="text-xs text-muted-foreground">XP</div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}