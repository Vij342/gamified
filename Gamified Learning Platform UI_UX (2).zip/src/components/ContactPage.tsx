import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  MessageSquare, 
  Send,
  CheckCircle,
  AlertCircle,
  Info,
  HelpCircle,
  Bug,
  Lightbulb,
  Star,
  Bot,
  Home
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner@2.0.3";

interface ContactPageProps {
  onBack: () => void;
}

const contactMethods = [
  {
    icon: Mail,
    title: "Email Support",
    description: "Get detailed help via email",
    contact: "shaddushubham@gmail.com",
    responseTime: "Within 4 hours",
    color: "bg-blue-500"
  },
  {
    icon: Bot,
    title: "AI Assistant",
    description: "24/7 AI-powered support",
    contact: "Click below to start chat",
    responseTime: "Instant",
    color: "bg-green-500"
  },
  {
    icon: Phone,
    title: "Phone Support",
    description: "Speak directly with our team",
    contact: "+917073201760",
    responseTime: "Immediate",
    color: "bg-purple-500"
  }
];

const inquiryTypes = [
  { value: "general", label: "General Question", icon: HelpCircle },
  { value: "technical", label: "Technical Issue", icon: Bug },
  { value: "feature", label: "Feature Request", icon: Lightbulb },
  { value: "billing", label: "Billing Support", icon: Info },
  { value: "feedback", label: "Feedback", icon: Star },
  { value: "teacher", label: "Teacher Support", icon: MessageSquare },
  { value: "family", label: "Family Account Help", icon: MessageSquare }
];

const faqs = [
  {
    question: "How quickly will I receive a response?",
    answer: "We aim to respond to all inquiries within 4 hours during business hours. For urgent technical issues, please use our live chat for immediate assistance."
  },
  {
    question: "Do you offer phone support?",
    answer: "Yes! Phone support is available Monday-Friday, 9 AM to 6 PM EST. For immediate help outside these hours, try our live chat or email support."
  },
  {
    question: "Can I schedule a demo for my school?",
    answer: "Absolutely! We offer personalized demos for educators and schools. Please select 'Teacher Support' as your inquiry type and mention that you'd like to schedule a demo."
  }
];

export function ContactPage({ onBack }: ContactPageProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    inquiryType: "",
    subject: "",
    message: "",
    priority: "normal"
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showAIChat, setShowAIChat] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { role: "assistant", content: "Hi! I'm EduSpark's AI assistant. How can I help you today?" }
  ]);
  const [chatInput, setChatInput] = useState("");

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setSubmitted(true);
    toast.success("Message sent successfully! We'll get back to you soon.");
    
    // Reset form after successful submission
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: "",
        email: "",
        inquiryType: "",
        subject: "",
        message: "",
        priority: "normal"
      });
    }, 3000);
  };

  const handleAIChat = async (message: string) => {
    if (!message.trim()) return;
    
    // Add user message
    const newMessages = [...chatMessages, { role: "user", content: message }];
    setChatMessages(newMessages);
    setChatInput("");
    
    // Simulate AI response
    setTimeout(() => {
      const responses = [
        "I understand your question. Let me help you with that!",
        "Great question! For technical issues, I recommend checking our help documentation first.",
        "I can help you with that. Would you like me to connect you with a human agent?",
        "Thanks for reaching out! For account-related queries, please use the contact form above.",
        "I'm here to assist! What specific area of EduSpark would you like help with?",
        "That's a common question. Let me provide you with some quick solutions...",
        "I can definitely help with that! Would you like step-by-step guidance?"
      ];
      
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setChatMessages([...newMessages, { role: "assistant", content: randomResponse }]);
    }, 1000);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <Home className="h-4 w-4" />
          Back to Home
        </Button>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          Get in Touch
        </h1>
        <div className="w-24" /> {/* Spacer for center alignment */}
      </div>
      
      <div className="text-center mb-12">
        <p className="text-xl text-muted-foreground">
          We're here to help! Reach out with any questions, feedback, or support needs.
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Contact Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="h-5 w-5" />
                Send us a Message
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Personal Information */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange("name", e.target.value)}
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange("email", e.target.value)}
                        placeholder="your.email@example.com"
                        required
                      />
                    </div>
                  </div>

                  {/* Inquiry Details */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="inquiryType">Inquiry Type *</Label>
                      <Select value={formData.inquiryType} onValueChange={(value) => handleInputChange("inquiryType", value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select inquiry type" />
                        </SelectTrigger>
                        <SelectContent>
                          {inquiryTypes.map((type) => {
                            const IconComponent = type.icon;
                            return (
                              <SelectItem key={type.value} value={type.value}>
                                <div className="flex items-center gap-2">
                                  <IconComponent className="h-4 w-4" />
                                  {type.label}
                                </div>
                              </SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="priority">Priority</Label>
                      <Select value={formData.priority} onValueChange={(value) => handleInputChange("priority", value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low - General inquiry</SelectItem>
                          <SelectItem value="normal">Normal - Standard support</SelectItem>
                          <SelectItem value="high">High - Urgent issue</SelectItem>
                          <SelectItem value="critical">Critical - System down</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Subject */}
                  <div>
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      value={formData.subject}
                      onChange={(e) => handleInputChange("subject", e.target.value)}
                      placeholder="Brief summary of your inquiry"
                      required
                    />
                  </div>

                  {/* Message */}
                  <div>
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      placeholder="Please provide as much detail as possible about your inquiry..."
                      className="min-h-32"
                      required
                    />
                  </div>

                  {/* Priority Indicators */}
                  <div className="flex flex-wrap gap-2">
                    <Badge className={formData.priority === "critical" ? "bg-red-500" : formData.priority === "high" ? "bg-orange-500" : "bg-blue-500"}>
                      Priority: {formData.priority.charAt(0).toUpperCase() + formData.priority.slice(1)}
                    </Badge>
                    {formData.inquiryType && (
                      <Badge variant="outline">
                        {inquiryTypes.find(t => t.value === formData.inquiryType)?.label}
                      </Badge>
                    )}
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                    size="lg"
                  >
                    {isSubmitting ? (
                      <motion.div
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        className="w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                      />
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Send Message
                      </>
                    )}
                  </Button>
                </form>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center py-12"
                >
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-green-600 mb-2">Message Sent Successfully!</h3>
                  <p className="text-muted-foreground mb-4">
                    Thank you for contacting us. We've received your message and will respond within 4 hours.
                  </p>
                  <Badge className="bg-green-100 text-green-800">
                    Ticket #ES-{Date.now().toString().slice(-6)}
                  </Badge>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Contact Methods */}
          <Card>
            <CardHeader>
              <CardTitle>Contact Methods</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {contactMethods.map((method) => {
                const IconComponent = method.icon;
                return (
                  <div key={method.title} className="flex items-start gap-3 p-3 rounded-lg border">
                    <div className={`${method.color} p-2 rounded-lg text-white`}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold">{method.title}</h4>
                      <p className="text-sm text-muted-foreground mb-1">{method.description}</p>
                      <p className="text-sm font-medium">{method.contact}</p>
                      <Badge variant="secondary" className="mt-1 text-xs">
                        {method.responseTime}
                      </Badge>
                      {method.title === "AI Assistant" && (
                        <Button 
                          onClick={() => setShowAIChat(true)}
                          size="sm" 
                          className="mt-2 w-full"
                        >
                          Start AI Chat
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Office Hours */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Support Hours
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span className="font-medium">9:00 AM - 6:00 PM EST</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span className="font-medium">10:00 AM - 4:00 PM EST</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span className="text-muted-foreground">Closed</span>
                </div>
              </div>
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  <Info className="h-4 w-4 inline mr-1" />
                  Email support is available 24/7 with responses within 4 hours during business hours.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Quick FAQs */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Answers</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="pb-3 border-b last:border-b-0">
                  <h4 className="font-medium text-sm mb-2">{faq.question}</h4>
                  <p className="text-xs text-muted-foreground">{faq.answer}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Office Location */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Our Office
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1653212883731-4d5bc66e0181?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b21lciUyMHN1cHBvcnQlMjBoZWxwJTIwZGVza3xlbnwxfHx8fDE3NTc3NzgzNzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="EduSpark office"
                  className="w-full h-32 object-cover rounded-lg"
                />
                <div className="text-sm">
                  <p className="font-medium">EduSpark Headquarters</p>
                  <p className="text-muted-foreground">
                    123 Learning Street<br />
                    Education District<br />
                    San Francisco, CA 94105
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Chat Dialog */}
      <AnimatePresence>
        {showAIChat && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50"
              onClick={() => setShowAIChat(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed bottom-4 right-4 w-96 h-96 bg-white rounded-lg shadow-2xl z-50 flex flex-col"
            >
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 text-white p-4 rounded-t-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Bot className="h-5 w-5" />
                    <h3 className="font-semibold">EduSpark AI Assistant</h3>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowAIChat(false)}
                    className="text-white hover:bg-white/20"
                  >
                    ×
                  </Button>
                </div>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chatMessages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-lg ${
                        message.role === "user"
                          ? "bg-blue-500 text-white"
                          : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {message.content}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="p-4 border-t">
                <div className="flex gap-2">
                  <Input
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Type your message..."
                    onKeyPress={(e) => {
                      if (e.key === "Enter") {
                        handleAIChat(chatInput);
                      }
                    }}
                  />
                  <Button onClick={() => handleAIChat(chatInput)}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}