import { useState } from "react";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { motion } from "motion/react";

interface SkillAssessmentProps {
  language: string;
  onComplete: (skillLevel: string) => void;
  onBack: () => void;
}

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  subject: string;
  icon: string;
}

export function SkillAssessment({ language, onComplete, onBack }: SkillAssessmentProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);

  const questions: Question[] = [
    {
      id: 1,
      question: "What is ¼ + ½?",
      options: ["¾", "⅓", "¼", "1"],
      correctAnswer: 0,
      subject: "Mathematics",
      icon: "🔢"
    },
    {
      id: 2,
      question: "Which planet is closest to the Sun?",
      options: ["Venus", "Mercury", "Earth", "Mars"],
      correctAnswer: 1,
      subject: "Science",
      icon: "🔬"
    },
    {
      id: 3,
      question: "What is the past tense of 'go'?",
      options: ["Goes", "Going", "Went", "Gone"],
      correctAnswer: 2,
      subject: "English",
      icon: "📝"
    },
    {
      id: 4,
      question: "What is 15 × 4?",
      options: ["50", "60", "65", "70"],
      correctAnswer: 1,
      subject: "Mathematics",
      icon: "🔢"
    },
    {
      id: 5,
      question: "Which gas do plants absorb from the air?",
      options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
      correctAnswer: 2,
      subject: "Science",
      icon: "🌱"
    }
  ];

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleAnswerSelect = (answerIndex: number) => {
    setSelectedAnswer(answerIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer !== null) {
      const newAnswers = [...answers, selectedAnswer];
      setAnswers(newAnswers);

      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
      } else {
        // Assessment complete - calculate skill level
        const correctAnswers = newAnswers.reduce((count, answer, index) => {
          return count + (answer === questions[index].correctAnswer ? 1 : 0);
        }, 0);

        let skillLevel = "beginner";
        if (correctAnswers >= 4) skillLevel = "advanced";
        else if (correctAnswers >= 2) skillLevel = "intermediate";

        onComplete(skillLevel);
      }
    }
  };

  const getLanguageText = (key: string) => {
    const texts: Record<string, Record<string, string>> = {
      en: {
        title: "Skill Assessment",
        subtitle: "Let's see what you know!",
        questionProgress: "Question",
        of: "of",
        nextButton: "Next Question",
        finishButton: "Finish Assessment",
        backButton: "Back"
      },
      hi: {
        title: "कौशल मूल्यांकन",
        subtitle: "आइए देखते हैं कि आप क्या जानते हैं!",
        questionProgress: "प्रश्न",
        of: "का",
        nextButton: "अगला प्रश्न",
        finishButton: "मूल्यांकन पूरा करें",
        backButton: "वापस"
      }
    };
    return texts[language]?.[key] || texts.en[key];
  };

  const currentQ = questions[currentQuestion];

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 via-pink-600 to-purple-600 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 max-w-2xl w-full shadow-2xl"
      >
        {/* Header */}
        <div className="text-center mb-6">
          <div className="bg-gradient-to-r from-orange-600 to-pink-600 bg-clip-text text-transparent mb-2">
            <h1 className="text-3xl font-bold">{getLanguageText("title")}</h1>
          </div>
          <p className="text-gray-600">{getLanguageText("subtitle")}</p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">
              {getLanguageText("questionProgress")} {currentQuestion + 1} {getLanguageText("of")} {questions.length}
            </span>
            <span className="text-2xl">{currentQ.icon}</span>
          </div>
          <Progress value={progress} className="h-3 bg-gray-200" />
        </div>

        {/* Question */}
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
          className="mb-8"
        >
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-6 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-gradient-to-r from-orange-500 to-pink-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">
                {currentQuestion + 1}
              </div>
              <span className="text-xs text-gray-500 bg-gray-200 px-2 py-1 rounded-full">
                {currentQ.subject}
              </span>
            </div>
            <h2 className="text-xl font-semibold text-gray-800">
              {currentQ.question}
            </h2>
          </div>

          {/* Answer Options */}
          <div className="grid gap-3">
            {currentQ.options.map((option, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleAnswerSelect(index)}
                className={`p-4 text-left border-2 rounded-xl transition-all duration-200 ${
                  selectedAnswer === index
                    ? "border-orange-500 bg-orange-50 text-orange-700"
                    : "border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                    selectedAnswer === index
                      ? "border-orange-500 bg-orange-500"
                      : "border-gray-300"
                  }`}>
                    {selectedAnswer === index && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="w-3 h-3 bg-white rounded-full"
                      />
                    )}
                  </div>
                  <span className="text-lg">{option}</span>
                </div>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Navigation */}
        <div className="flex gap-3">
          <Button
            onClick={onBack}
            variant="outline"
            className="px-6 border-2 rounded-xl"
          >
            ← {getLanguageText("backButton")}
          </Button>
          
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex-1"
          >
            <Button
              onClick={handleNextQuestion}
              disabled={selectedAnswer === null}
              className="w-full h-12 text-lg bg-gradient-to-r from-orange-600 to-pink-600 hover:from-orange-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg"
            >
              {currentQuestion === questions.length - 1 
                ? getLanguageText("finishButton")
                : getLanguageText("nextButton")
              }
              <motion.span
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="ml-2"
              >
                →
              </motion.span>
            </Button>
          </motion.div>
        </div>

        {/* Background Icons */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              animate={{ 
                y: [0, -20, 0],
                rotate: [0, 360]
              }}
              transition={{ 
                duration: 4 + i, 
                repeat: Infinity,
                ease: "easeInOut",
                delay: i * 0.5
              }}
              className={`absolute text-2xl opacity-10 ${
                i % 2 === 0 ? 'top-20 right-20' : 'bottom-20 left-20'
              }`}
              style={{
                transform: `translate(${i * 30}px, ${i * 20}px)`
              }}
            >
              {['📐', '🧪', '✏️', '🌟', '🎯'][i]}
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}