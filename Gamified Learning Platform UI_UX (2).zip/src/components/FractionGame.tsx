import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion, AnimatePresence } from "motion/react";
import { Star, ArrowLeft, CheckCircle, XCircle } from "lucide-react";

interface FractionGameProps {
  onBack: () => void;
  onComplete: (score: number, xpEarned: number) => void;
}

interface FractionProblem {
  id: number;
  instruction: string;
  targetFraction: string;
  numerator: number;
  denominator: number;
  totalSlices: number;
  requiredSlices: number;
}

export function FractionGame({ onBack, onComplete }: FractionGameProps) {
  const [currentProblem, setCurrentProblem] = useState(0);
  const [selectedSlices, setSelectedSlices] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [gameComplete, setGameComplete] = useState(false);

  const problems: FractionProblem[] = [
    {
      id: 1,
      instruction: "Select ¾ of the pizza",
      targetFraction: "¾",
      numerator: 3,
      denominator: 4,
      totalSlices: 4,
      requiredSlices: 3
    },
    {
      id: 2,  
      instruction: "Select ½ of the pizza",
      targetFraction: "½",
      numerator: 1,
      denominator: 2,
      totalSlices: 2,
      requiredSlices: 1
    },
    {
      id: 3,
      instruction: "Select ⅖ of the pizza",
      targetFraction: "⅖",
      numerator: 2,
      denominator: 5,
      totalSlices: 5,
      requiredSlices: 2
    }
  ];

  const currentQ = problems[currentProblem];
  const progress = ((currentProblem + 1) / problems.length) * 100;

  const handleSliceClick = (sliceIndex: number) => {
    if (showResult) return;

    setSelectedSlices(prev => {
      if (prev.includes(sliceIndex)) {
        return prev.filter(i => i !== sliceIndex);
      } else {
        return [...prev, sliceIndex];
      }
    });
  };

  const handleSubmitAnswer = () => {
    const correct = selectedSlices.length === currentQ.requiredSlices;
    setIsCorrect(correct);
    setShowResult(true);
    
    if (correct) {
      setScore(prev => prev + 1);
    }

    // Auto-advance after 2 seconds
    setTimeout(() => {
      if (currentProblem < problems.length - 1) {
        setCurrentProblem(prev => prev + 1);
        setSelectedSlices([]);
        setShowResult(false);
      } else {
        setGameComplete(true);
      }
    }, 2000);
  };

  const handleGameComplete = () => {
    const finalScore = score;
    const xpEarned = finalScore * 50 + (finalScore === problems.length ? 100 : 0); // Bonus for perfect score
    onComplete(finalScore, xpEarned);
  };

  useEffect(() => {
    if (gameComplete) {
      setTimeout(handleGameComplete, 1000);
    }
  }, [gameComplete]);

  const renderPizzaSlices = () => {
    const slices = [];
    const totalSlices = currentQ.totalSlices;
    const anglePerSlice = 360 / totalSlices;

    for (let i = 0; i < totalSlices; i++) {
      const startAngle = i * anglePerSlice;
      const endAngle = (i + 1) * anglePerSlice;
      
      // Calculate slice path
      const startAngleRad = (startAngle * Math.PI) / 180;
      const endAngleRad = (endAngle * Math.PI) / 180;
      
      const radius = 80;
      const centerX = 100;
      const centerY = 100;
      
      const x1 = centerX + radius * Math.cos(startAngleRad);
      const y1 = centerY + radius * Math.sin(startAngleRad);
      const x2 = centerX + radius * Math.cos(endAngleRad);
      const y2 = centerY + radius * Math.sin(endAngleRad);
      
      const largeArcFlag = anglePerSlice > 180 ? 1 : 0;
      
      const pathData = [
        `M ${centerX} ${centerY}`,
        `L ${x1} ${y1}`,
        `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${x2} ${y2}`,
        'Z'
      ].join(' ');

      const isSelected = selectedSlices.includes(i);
      const isCorrectSlice = showResult && i < currentQ.requiredSlices;
      const isWrongSelection = showResult && isSelected && i >= currentQ.requiredSlices;

      slices.push(
        <motion.path
          key={i}
          d={pathData}
          fill={
            showResult
              ? isCorrectSlice
                ? "#10b981" // Green for correct
                : isWrongSelection
                ? "#ef4444" // Red for wrong
                : isSelected
                ? "#f59e0b" // Yellow for selected but not shown yet
                : "#fbbf24" // Default pizza color
              : isSelected
              ? "#f59e0b" // Selected color
              : "#fbbf24" // Default pizza color
          }
          stroke="#d97706"
          strokeWidth="2"
          className="cursor-pointer transition-all duration-200"
          onClick={() => handleSliceClick(i)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: i * 0.1 }}
        />
      );
    }

    return slices;
  };

  if (gameComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 max-w-md w-full shadow-2xl text-center"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            className="text-6xl mb-4"
          >
            🍕
          </motion.div>
          <h1 className="text-3xl font-bold mb-4 bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
            Pizza Master!
          </h1>
          <p className="text-xl mb-6">
            You got {score} out of {problems.length} fractions correct!
          </p>
          <motion.div className="flex justify-center gap-1 mb-6">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.2 }}
              >
                <Star
                  className={`w-8 h-8 ${
                    i < score ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                  }`}
                />
              </motion.div>
            ))}
          </motion.div>
          <Button
            onClick={handleGameComplete}
            className="w-full h-12 text-lg bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 rounded-xl"
          >
            Continue 🚀
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 via-red-500 to-pink-500 p-4">
      <div className="max-w-2xl mx-auto pt-8">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button
            onClick={onBack}
            variant="outline"
            className="bg-white/90 backdrop-blur-sm border-2 rounded-xl"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <Badge className="bg-white/90 backdrop-blur-sm text-gray-700 px-4 py-2 text-lg">
            {currentProblem + 1} / {problems.length}
          </Badge>
        </div>

        {/* Game Title */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
            <CardHeader>
              <CardTitle className="text-3xl bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                🍕 Fraction Fun
              </CardTitle>
              <p className="text-gray-600 text-lg">
                Click on the pizza slices to show the fraction!
              </p>
            </CardHeader>
          </Card>
        </motion.div>

        {/* Main Game Card */}
        <motion.div
          key={currentProblem}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-0">
            <CardHeader>
              <div className="text-center">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">
                  {currentQ.instruction}
                </h2>
                <div className="text-4xl font-bold text-orange-600">
                  {currentQ.targetFraction}
                </div>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Pizza Visual */}
              <div className="flex justify-center">
                <motion.svg
                  width="200"
                  height="200"
                  viewBox="0 0 200 200"
                  className="bg-gray-50 rounded-full shadow-inner"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 15 }}
                >
                  {renderPizzaSlices()}
                  
                  {/* Pizza base circle */}
                  <circle
                    cx="100"
                    cy="100"
                    r="80"
                    fill="none"
                    stroke="#d97706"
                    strokeWidth="3"
                  />
                  
                  {/* Center dot */}
                  <circle
                    cx="100"
                    cy="100"
                    r="3"
                    fill="#d97706"
                  />
                </motion.svg>
              </div>

              {/* Instructions */}
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  Selected: {selectedSlices.length} / {currentQ.requiredSlices} slices
                </p>
                
                {/* Result Display */}
                <AnimatePresence>
                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className={`p-4 rounded-xl ${
                        isCorrect ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      <div className="flex items-center justify-center gap-2">
                        {isCorrect ? (
                          <>
                            <CheckCircle className="w-5 h-5" />
                            <span className="font-semibold">Shabash! Correct! +10 points</span>
                          </>
                        ) : (
                          <>
                            <XCircle className="w-5 h-5" />
                            <span className="font-semibold">Try again! You selected {selectedSlices.length} slices</span>
                          </>
                        )}
                      </div>
                      {isCorrect && (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          className="text-2xl mt-2"
                        >
                          🎉
                        </motion.div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Submit Button */}
              {!showResult && (
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Button
                    onClick={handleSubmitAnswer}
                    disabled={selectedSlices.length === 0}
                    className="w-full h-12 text-lg bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg"
                  >
                    Check Answer ✨
                  </Button>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Score Display */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center mt-6"
        >
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-4 inline-block shadow-lg">
            <div className="flex items-center gap-4">
              <div className="flex gap-1">
                {[...Array(3)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-6 h-6 ${
                      i < score ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-lg font-semibold text-gray-700">
                Score: {score} / {problems.length}
              </span>
            </div>
          </div>
        </motion.div>

      </div>
    </div>
  );
}