import { useState, useEffect } from "react";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Wifi, WifiOff, RefreshCw, CloudOff, Cloud } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface OfflineDetectorProps {
  onRetry?: () => void;
}

export function OfflineDetector({ onRetry }: OfflineDetectorProps) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOfflineAlert, setShowOfflineAlert] = useState(false);
  const [wasOffline, setWasOffline] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (wasOffline) {
        // Show reconnection success briefly
        setShowOfflineAlert(true);
        setTimeout(() => setShowOfflineAlert(false), 3000);
        setWasOffline(false);
        
        // Trigger sync if available
        if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
          navigator.serviceWorker.ready.then((registration) => {
            registration.sync.register('user-progress');
            registration.sync.register('quiz-submission');
          });
        }
        
        onRetry?.();
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setShowOfflineAlert(true);
      setWasOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Show initial offline state if already offline
    if (!navigator.onLine) {
      setShowOfflineAlert(true);
      setWasOffline(true);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [onRetry, wasOffline]);

  return (
    <>
      {/* Connection Status Indicator */}
      <Badge 
        className={`fixed top-20 right-4 z-50 transition-all duration-300 ${
          isOnline 
            ? 'bg-green-500 hover:bg-green-600' 
            : 'bg-red-500 hover:bg-red-600'
        }`}
      >
        {isOnline ? (
          <>
            <Cloud className="h-3 w-3 mr-1" />
            Online
          </>
        ) : (
          <>
            <CloudOff className="h-3 w-3 mr-1" />
            Offline
          </>
        )}
      </Badge>

      {/* Offline/Online Alert */}
      <AnimatePresence>
        {showOfflineAlert && (
          <motion.div
            initial={{ opacity: 0, y: -100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -100 }}
            className="fixed top-24 left-4 right-4 z-40 max-w-md mx-auto"
          >
            <Alert className={`${
              isOnline 
                ? 'border-green-500 bg-green-50 text-green-800' 
                : 'border-orange-500 bg-orange-50 text-orange-800'
            }`}>
              <div className="flex items-center gap-3">
                {isOnline ? (
                  <Wifi className="h-5 w-5 text-green-600" />
                ) : (
                  <WifiOff className="h-5 w-5 text-orange-600" />
                )}
                <div className="flex-1">
                  <AlertDescription className="font-medium">
                    {isOnline ? (
                      <>
                        <span className="text-green-700">Connected!</span>
                        <br />
                        <span className="text-sm text-green-600">
                          Your progress has been synced.
                        </span>
                      </>
                    ) : (
                      <>
                        <span className="text-orange-700">You're offline</span>
                        <br />
                        <span className="text-sm text-orange-600">
                          Don't worry! You can still take quizzes and your progress will be saved locally.
                        </span>
                      </>
                    )}
                  </AlertDescription>
                </div>
                {!isOnline && onRetry && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      onRetry();
                      // Try to reconnect
                      window.location.reload();
                    }}
                    className="border-orange-300 text-orange-700 hover:bg-orange-100"
                  >
                    <RefreshCw className="h-3 w-3 mr-1" />
                    Retry
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setShowOfflineAlert(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ×
                </Button>
              </div>
            </Alert>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

// Hook for offline detection
export function useOfflineDetection() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [connectionType, setConnectionType] = useState<string>('unknown');

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Get connection information if available
    if ('connection' in navigator) {
      const connection = (navigator as any).connection;
      setConnectionType(connection.effectiveType || connection.type || 'unknown');
      
      const handleConnectionChange = () => {
        setConnectionType(connection.effectiveType || connection.type || 'unknown');
      };
      
      connection.addEventListener('change', handleConnectionChange);
      
      return () => {
        window.removeEventListener('online', handleOnline);
        window.removeEventListener('offline', handleOffline);
        connection.removeEventListener('change', handleConnectionChange);
      };
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return { isOnline, connectionType };
}