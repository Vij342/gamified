import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Users, 
  BookOpen, 
  TrendingUp, 
  Clock, 
  CheckCircle,
  AlertCircle,
  Plus,
  Search,
  Filter,
  Download,
  UserCheck,
  Star,
  Calendar,
  BarChart3,
  Target
} from "lucide-react";
import { motion } from "motion/react";

interface Student {
  id: string;
  name: string;
  avatar: string;
  level: number;
  xp: number;
  accuracy: number;
  quizzesCompleted: number;
  streak: number;
  lastActive: string;
  totalStudyTime: number;
  strongSubjects: string[];
  needsHelp: string[];
}

interface TeacherTrackingProps {
  onBack: () => void;
}

const classroomData = {
  totalStudents: 28,
  activeToday: 22,
  averageAccuracy: 87,
  totalQuizzes: 342,
  averageStudyTime: 45
};

const students: Student[] = [
  {
    id: "1",
    name: "Emma Wilson",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b2292bb9?w=150&h=150&fit=crop&crop=face",
    level: 12,
    xp: 2340,
    accuracy: 94,
    quizzesCompleted: 28,
    streak: 7,
    lastActive: "2 hours ago",
    totalStudyTime: 180,
    strongSubjects: ["Mathematics", "Science"],
    needsHelp: ["History"]
  },
  {
    id: "2",
    name: "Alex Johnson", 
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    level: 10,
    xp: 1890,
    accuracy: 78,
    quizzesCompleted: 22,
    streak: 3,
    lastActive: "1 day ago",
    totalStudyTime: 145,
    strongSubjects: ["English", "Art"],
    needsHelp: ["Mathematics", "Science"]
  },
  {
    id: "3",
    name: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    level: 14,
    xp: 2650,
    accuracy: 91,
    quizzesCompleted: 31,
    streak: 5,
    lastActive: "30 minutes ago",
    totalStudyTime: 220,
    strongSubjects: ["Mathematics", "Science", "Geography"],
    needsHelp: ["Art"]
  },
  {
    id: "4",
    name: "Mike Rodriguez",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    level: 8,
    xp: 1420,
    accuracy: 65,
    quizzesCompleted: 18,
    streak: 1,
    lastActive: "3 days ago",
    totalStudyTime: 95,
    strongSubjects: ["Geography"],
    needsHelp: ["Mathematics", "English", "Science"]
  }
];

const recentAssignments = [
  { id: "1", title: "Algebra Basics Quiz", subject: "Mathematics", dueDate: "Tomorrow", completed: 18, total: 28 },
  { id: "2", title: "Chemical Elements", subject: "Science", dueDate: "Dec 20", completed: 25, total: 28 },
  { id: "3", title: "World Geography", subject: "Geography", dueDate: "Dec 22", completed: 12, total: 28 }
];

export function TeacherTracking({ onBack }: TeacherTrackingProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTab, setSelectedTab] = useState("overview");

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Teacher Dashboard
          </h1>
          <p className="text-muted-foreground mt-2">
            Track student progress and manage classroom activities
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button onClick={onBack} variant="outline">
            <Users className="mr-2 h-4 w-4" />
            Back to Main
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Create Assignment
          </Button>
        </div>
      </div>

      {/* Hero Section with Image */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white mb-8 relative overflow-hidden">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-4">Welcome Back, Teacher! 📚</h2>
            <p className="text-lg opacity-90 mb-6">
              Your classroom is thriving! {classroomData.activeToday} out of {classroomData.totalStudents} students 
              were active today with an average accuracy of {classroomData.averageAccuracy}%.
            </p>
            <div className="flex gap-4">
              <Button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm">
                <Download className="mr-2 h-4 w-4" />
                Export Report
              </Button>
              <Button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm">
                <Calendar className="mr-2 h-4 w-4" />
                Schedule Quiz
              </Button>
            </div>
          </div>
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1664382951771-40432ecc81bd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFjaGVyJTIwY2xhc3Nyb29tJTIwZWR1Y2F0aW9ufGVufDF8fHx8MTc1Nzc3ODM3M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Teacher in classroom"
              className="w-full h-64 object-cover rounded-lg opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-blue-600/40 to-transparent rounded-lg"></div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{classroomData.totalStudents}</div>
            <div className="text-sm text-muted-foreground">Total Students</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <UserCheck className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{classroomData.activeToday}</div>
            <div className="text-sm text-muted-foreground">Active Today</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{classroomData.averageAccuracy}%</div>
            <div className="text-sm text-muted-foreground">Avg Accuracy</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <BookOpen className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{classroomData.totalQuizzes}</div>
            <div className="text-sm text-muted-foreground">Quizzes Done</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="h-8 w-8 text-red-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{classroomData.averageStudyTime}m</div>
            <div className="text-sm text-muted-foreground">Avg Study Time</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="students">Students</TabsTrigger>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Recent Activity & Assignments */}
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {students.slice(0, 4).map((student) => (
                    <div key={student.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                      <ImageWithFallback
                        src={student.avatar}
                        alt={student.name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <p className="font-medium text-sm">{student.name}</p>
                        <p className="text-xs text-muted-foreground">
                          Completed Mathematics Quiz • {student.lastActive}
                        </p>
                      </div>
                      <Badge variant="secondary">{student.accuracy}%</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Active Assignments
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentAssignments.map((assignment) => (
                    <div key={assignment.id} className="p-3 rounded-lg border">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{assignment.title}</h4>
                        <Badge>{assignment.subject}</Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Due: {assignment.dueDate}</span>
                        <span className="text-muted-foreground">
                          {assignment.completed}/{assignment.total} completed
                        </span>
                      </div>
                      <Progress 
                        value={(assignment.completed / assignment.total) * 100} 
                        className="mt-2 h-2"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Students Needing Attention */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-orange-500" />
                Students Needing Attention
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                {students.filter(s => s.accuracy < 80 || s.streak < 3).map((student) => (
                  <div key={student.id} className="p-4 rounded-lg border border-orange-200 bg-orange-50">
                    <div className="flex items-center gap-3 mb-3">
                      <ImageWithFallback
                        src={student.avatar}
                        alt={student.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div>
                        <h4 className="font-medium">{student.name}</h4>
                        <p className="text-sm text-muted-foreground">Level {student.level}</p>
                      </div>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Accuracy:</span>
                        <span className={student.accuracy < 80 ? "text-red-600 font-medium" : ""}>
                          {student.accuracy}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Streak:</span>
                        <span className={student.streak < 3 ? "text-orange-600 font-medium" : ""}>
                          {student.streak} days
                        </span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Needs help: {student.needsHelp.join(", ")}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="students" className="space-y-6">
          {/* Search and Filter */}
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline">
              <Filter className="mr-2 h-4 w-4" />
              Filter
            </Button>
          </div>

          {/* Students Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStudents.map((student, index) => (
              <motion.div
                key={student.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="hover:shadow-lg transition-all duration-300">
                  <CardHeader className="pb-3">
                    <div className="flex items-center gap-3">
                      <ImageWithFallback
                        src={student.avatar}
                        alt={student.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <CardTitle className="text-lg">{student.name}</CardTitle>
                        <p className="text-sm text-muted-foreground">Level {student.level}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">XP:</span>
                          <span className="font-medium ml-2">{student.xp}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Accuracy:</span>
                          <span className="font-medium ml-2">{student.accuracy}%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Quizzes:</span>
                          <span className="font-medium ml-2">{student.quizzesCompleted}</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Streak:</span>
                          <span className="font-medium ml-2">{student.streak} days</span>
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Strong in:</p>
                        <div className="flex flex-wrap gap-1">
                          {student.strongSubjects.map((subject) => (
                            <Badge key={subject} className="bg-green-100 text-green-800 text-xs">
                              {subject}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      {student.needsHelp.length > 0 && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-2">Needs help with:</p>
                          <div className="flex flex-wrap gap-1">
                            {student.needsHelp.map((subject) => (
                              <Badge key={subject} className="bg-orange-100 text-orange-800 text-xs">
                                {subject}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <p className="text-xs text-muted-foreground">
                        Last active: {student.lastActive}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="assignments">
          <Card>
            <CardHeader>
              <CardTitle>Assignment Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Assignment Feature Coming Soon</h3>
                <p className="text-muted-foreground mb-4">
                  Create custom quizzes, set deadlines, and track completion rates.
                </p>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  Request Early Access
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Advanced Analytics Coming Soon</h3>
                <p className="text-muted-foreground mb-4">
                  Get detailed insights into student performance, learning patterns, and progress trends.
                </p>
                <Button>
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Request Early Access
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}