import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { motion } from "motion/react";
import { Calendar, Clock, Target, Trophy, Star, BookOpen } from "lucide-react";

interface ProgressReportProps {
  onContinueLearning: () => void;
  onBack: () => void;
}

interface SubjectProgress {
  name: string;
  progress: number;
  color: string;
  icon: string;
  streak: number;
  lastStudied: string;
}

export function ProgressReport({ onContinueLearning, onBack }: ProgressReportProps) {
  const [weeklyGoal] = useState(75); // 75% completion goal
  const [currentWeekProgress] = useState(67); // Current progress
  
  const subjectProgress: SubjectProgress[] = [
    {
      name: "Mathematics",
      progress: 75,
      color: "from-blue-500 to-blue-600",
      icon: "🔢",
      streak: 5,
      lastStudied: "Today"
    },
    {
      name: "Science",
      progress: 60,
      color: "from-green-500 to-green-600",
      icon: "🔬",
      streak: 3,
      lastStudied: "Yesterday"
    },
    {
      name: "English",
      progress: 45,
      color: "from-purple-500 to-purple-600",
      icon: "📝",
      streak: 2,
      lastStudied: "2 days ago"
    },
    {
      name: "Geography",
      progress: 30,
      color: "from-orange-500 to-orange-600",
      icon: "🌍",
      streak: 1,
      lastStudied: "3 days ago"
    }
  ];

  const achievements = [
    {
      name: "Math Wizard",
      description: "Completed 50 math problems",
      icon: "🏆",
      color: "from-yellow-400 to-yellow-500",
      earned: true
    },
    {
      name: "Science Explorer",
      description: "Studied 5 science topics",
      icon: "🔬",
      color: "from-green-400 to-green-500",
      earned: true
    },
    {
      name: "Speed Learner",
      description: "Complete quiz in under 2 minutes",
      icon: "⚡",
      color: "from-blue-400 to-blue-500",
      earned: false
    },
    {
      name: "Consistent Scholar",
      description: "7-day learning streak",
      icon: "🔥",
      color: "from-red-400 to-red-500",
      earned: false
    }
  ];

  const stats = [
    {
      label: "Total Study Time",
      value: "12h 45m",
      icon: <Clock className="w-5 h-5" />,
      color: "text-blue-600"
    },
    {
      label: "Quizzes Completed",
      value: "23",
      icon: <Target className="w-5 h-5" />,
      color: "text-green-600"
    },
    {
      label: "Current Streak",
      value: "5 days",
      icon: <Star className="w-5 h-5" />,
      color: "text-orange-600"
    },
    {
      label: "XP Earned",
      value: "1,250",
      icon: <Trophy className="w-5 h-5" />,
      color: "text-purple-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-600 p-4">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 pt-8"
        >
          <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-2xl">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-2">
              Weekly Progress Report
            </h1>
            <p className="text-gray-600">Keep up the great work, Scholar! 🌟</p>
          </div>
        </motion.div>

        {/* Weekly Goal Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="mb-6 bg-white/95 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-600" />
                Weekly Goal Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg">Target: {weeklyGoal}%</span>
                  <span className="text-lg font-semibold text-indigo-600">
                    {currentWeekProgress}%
                  </span>
                </div>
                <Progress 
                  value={currentWeekProgress} 
                  className="h-4 bg-gray-200"
                />
                <div className="text-sm text-gray-600">
                  {currentWeekProgress >= weeklyGoal ? (
                    <span className="text-green-600 font-semibold">
                      🎉 Goal achieved! Great job!
                    </span>
                  ) : (
                    <span>
                      {weeklyGoal - currentWeekProgress}% more to reach your weekly goal
                    </span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6"
        >
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/95 backdrop-blur-sm shadow-xl border-0">
              <CardContent className="p-4 text-center">
                <div className={`${stat.color} mb-2 flex justify-center`}>
                  {stat.icon}
                </div>
                <div className="text-2xl font-bold text-gray-800">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </motion.div>

        {/* Subject Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="mb-6 bg-white/95 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-purple-600" />
                Subject Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {subjectProgress.map((subject, index) => (
                  <motion.div
                    key={subject.name}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{subject.icon}</span>
                        <div>
                          <h3 className="font-semibold">{subject.name}</h3>
                          <p className="text-sm text-gray-600">
                            Last studied: {subject.lastStudied}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-semibold text-gray-800">
                          {subject.progress}%
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {subject.streak} day streak
                        </Badge>
                      </div>
                    </div>
                    <Progress 
                      value={subject.progress} 
                      className="h-3 bg-gray-200"
                    />
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card className="mb-6 bg-white/95 backdrop-blur-sm shadow-xl border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-600" />
                Recent Achievements
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className={`p-4 rounded-xl border-2 ${
                      achievement.earned
                        ? `bg-gradient-to-r ${achievement.color} text-white shadow-lg`
                        : "bg-gray-50 border-gray-200 text-gray-400"
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{achievement.icon}</span>
                      <h3 className="font-semibold">{achievement.name}</h3>
                    </div>
                    <p className="text-sm opacity-90">
                      {achievement.description}
                    </p>
                    {!achievement.earned && (
                      <Badge variant="outline" className="mt-2 text-xs">
                        In Progress
                      </Badge>
                    )}
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="flex gap-4 pb-8"
        >
          <Button
            onClick={onBack}
            variant="outline"
            className="px-6 bg-white/95 backdrop-blur-sm border-2 rounded-xl"
          >
            ← Back
          </Button>
          
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex-1"
          >
            <Button
              onClick={onContinueLearning}
              className="w-full h-12 text-lg bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 rounded-xl shadow-lg"
            >
              Continue Learning
              <motion.span
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="ml-2"
              >
                🚀
              </motion.span>
            </Button>
          </motion.div>
        </motion.div>

      </div>
    </div>
  );
}