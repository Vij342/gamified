import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  BookOpen, 
  Brain, 
  Calculator, 
  Globe, 
  Microscope, 
  Palette,
  Play,
  Star,
  Clock,
  Users,
  TrendingUp
} from "lucide-react";

interface Subject {
  id: string;
  name: string;
  icon: any;
  color: string;
  progress: number;
  totalQuizzes: number;
  completedQuizzes: number;
  description: string;
}

interface DashboardProps {
  onStartQuiz: (subjectId: string) => void;
  onViewLeaderboard: () => void;
  onViewAchievements: () => void;
  onViewProgress?: () => void;
  onMultilingualDashboard?: () => void;
}

const subjects: Subject[] = [
  {
    id: "math",
    name: "Mathematics",
    icon: Calculator,
    color: "bg-blue-500",
    progress: 0,
    totalQuizzes: 24,
    completedQuizzes: 0,
    description: "Master numbers, equations, and problem-solving"
  },
  {
    id: "science",
    name: "Science",
    icon: Microscope,
    color: "bg-green-500",
    progress: 0,
    totalQuizzes: 20,
    completedQuizzes: 0,
    description: "Explore the wonders of physics, chemistry, and biology"
  },
  {
    id: "english",
    name: "English",
    icon: BookOpen,
    color: "bg-purple-500",
    progress: 0,
    totalQuizzes: 30,
    completedQuizzes: 0,
    description: "Improve grammar, vocabulary, and reading comprehension"
  },
  {
    id: "geography",
    name: "Geography",
    icon: Globe,
    color: "bg-orange-500",
    progress: 0,
    totalQuizzes: 16,
    completedQuizzes: 0,
    description: "Discover countries, capitals, and world cultures"
  },
  {
    id: "history",
    name: "History",
    icon: Brain,
    color: "bg-red-500",
    progress: 0,
    totalQuizzes: 22,
    completedQuizzes: 0,
    description: "Journey through time and historical events"
  },
  {
    id: "art",
    name: "Art & Culture",
    icon: Palette,
    color: "bg-pink-500",
    progress: 0,
    totalQuizzes: 18,
    completedQuizzes: 0,
    description: "Explore creativity, famous artists, and cultural heritage"
  }
];

export function Dashboard({ onStartQuiz, onViewLeaderboard, onViewAchievements, onViewProgress, onMultilingualDashboard }: DashboardProps) {
  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl p-8 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10">
          <h2 className="text-3xl font-bold mb-2">Welcome back, Scholar! 🎓</h2>
          <p className="text-lg opacity-90 mb-6">Ready to spark your learning journey today?</p>
          <div className="flex flex-wrap gap-4">
            <Button
              onClick={onViewAchievements}
              className="bg-white/20 hover:bg-white/30 backdrop-blur-sm"
            >
              <Star className="mr-2 h-4 w-4" />
              View Achievements
            </Button>
            <Button
              onClick={onViewLeaderboard}
              className="bg-white/20 hover:bg-white/30 backdrop-blur-sm"
            >
              <Users className="mr-2 h-4 w-4" />
              Leaderboard
            </Button>
            {onViewProgress && (
              <Button
                onClick={onViewProgress}
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm"
              >
                <TrendingUp className="mr-2 h-4 w-4" />
                Progress Report
              </Button>
            )}
          </div>
        </div>
        <div className="absolute right-4 top-4 opacity-20">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1732652835004-efc80cb31d9d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlZHVjYXRpb24lMjBsZWFybmluZyUyMGJvb2tzJTIwY29sb3JmdWx8ZW58MXx8fHwxNzU3NjkyNzMyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Learning illustration"
            className="w-32 h-32 object-cover rounded-lg"
          />
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Today's Progress</p>
                <p className="text-2xl font-bold text-blue-600">0/5</p>
                <p className="text-xs text-muted-foreground">Quizzes completed</p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Study Time</p>
                <p className="text-2xl font-bold text-green-600">0m</p>
                <p className="text-xs text-muted-foreground">This week</p>
              </div>
              <Clock className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Accuracy</p>
                <p className="text-2xl font-bold text-purple-600">0%</p>
                <p className="text-xs text-muted-foreground">Last 10 quizzes</p>
              </div>
              <Star className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Featured Games Section */}
      <div>
        <h3 className="text-2xl font-bold mb-6">🎮 Featured Games</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Fraction Fun */}
          <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-orange-100 to-red-100 border-orange-200">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="p-3 rounded-lg bg-gradient-to-r from-orange-500 to-red-500 text-white text-2xl">
                  🍕
                </div>
                <Badge className="bg-orange-500 text-white">NEW</Badge>
              </div>
              <CardTitle className="text-lg text-orange-800">Fraction Fun</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-orange-700 mb-4">
                Learn fractions by clicking pizza slices! Interactive visual learning made fun.
              </p>
              <Button
                onClick={() => onStartQuiz("fractionFun")}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 transition-colors"
              >
                <Play className="mr-2 h-4 w-4" />
                Play Game
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Multilingual Learning Option */}
      {onMultilingualDashboard && (
        <Card className="border-2 border-dashed border-blue-300 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <Globe className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-1">Multilingual Learning</h4>
                  <p className="text-muted-foreground text-sm">
                    Learn in your native language • 42+ Indian languages supported
                  </p>
                </div>
              </div>
              <Button 
                onClick={onMultilingualDashboard}
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
              >
                <Globe className="w-4 h-4 mr-2" />
                Start Multilingual Learning
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Subjects Grid */}
      <div>
        <h3 className="text-2xl font-bold mb-6">Choose Your Subject</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subjects.map((subject) => {
            const IconComponent = subject.icon;
            return (
              <Card key={subject.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className={`p-3 rounded-lg ${subject.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <Badge variant="secondary">
                      {subject.completedQuizzes}/{subject.totalQuizzes}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg">{subject.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {subject.description}
                  </p>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <span>{subject.progress}%</span>
                      </div>
                      <Progress value={subject.progress} className="h-2" />
                    </div>
                    
                    <Button
                      onClick={() => onStartQuiz(subject.id)}
                      className="w-full group-hover:bg-primary/90 transition-colors"
                    >
                      <Play className="mr-2 h-4 w-4" />
                      Start Quiz
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}