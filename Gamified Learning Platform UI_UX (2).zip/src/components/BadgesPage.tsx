import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { 
  Home,
  Trophy, 
  Star, 
  Flame, 
  Zap, 
  Brain, 
  Target, 
  Award,
  Crown,
  Gem,
  Medal,
  Shield,
  Sparkles,
  BookOpen,
  Calculator,
  Lightbulb,
  Timer,
  Check
} from "lucide-react";
import { motion } from "motion/react";

interface BadgeData {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  category: "achievement" | "milestone" | "streak" | "special";
  requirement: string;
  earned: boolean;
  progress?: number;
  maxProgress?: number;
  rarity: "common" | "rare" | "epic" | "legendary";
  xpReward: number;
  earnedDate?: string;
}

interface BadgesPageProps {
  onBack: () => void;
}

const allBadges: BadgeData[] = [
  // Achievement Badges
  {
    id: "first_quiz",
    name: "First Steps",
    description: "Complete your first quiz",
    icon: Star,
    category: "achievement",
    requirement: "Complete 1 quiz",
    earned: true,
    rarity: "common",
    xpReward: 50,
    earnedDate: "2024-01-15"
  },
  {
    id: "quiz_master",
    name: "Quiz Master",
    description: "Complete 50 quizzes",
    icon: Brain,
    category: "achievement",
    requirement: "Complete 50 quizzes",
    earned: false,
    progress: 12,
    maxProgress: 50,
    rarity: "epic",
    xpReward: 500
  },
  {
    id: "perfect_score",
    name: "Perfect Scholar",
    description: "Get 100% on any quiz",
    icon: Target,
    category: "achievement",
    requirement: "Score 100% on a quiz",
    earned: true,
    rarity: "rare",
    xpReward: 100,
    earnedDate: "2024-01-20"
  },
  
  // Milestone Badges
  {
    id: "level_5",
    name: "Rising Star",
    description: "Reach level 5",
    icon: Crown,
    category: "milestone",
    requirement: "Reach level 5",
    earned: false,
    progress: 3,
    maxProgress: 5,
    rarity: "rare",
    xpReward: 200
  },
  {
    id: "level_10",
    name: "Scholar Supreme",
    description: "Reach level 10",
    icon: Gem,
    category: "milestone",
    requirement: "Reach level 10",
    earned: false,
    progress: 3,
    maxProgress: 10,
    rarity: "epic",
    xpReward: 500
  },
  
  // Streak Badges
  {
    id: "streak_3",
    name: "Hot Streak",
    description: "Get 3 questions right in a row",
    icon: Flame,
    category: "streak",
    requirement: "3 correct answers in a row",
    earned: true,
    rarity: "common",
    xpReward: 75,
    earnedDate: "2024-01-18"
  },
  {
    id: "streak_10",
    name: "Unstoppable",
    description: "Get 10 questions right in a row",
    icon: Zap,
    category: "streak",
    requirement: "10 correct answers in a row",
    earned: false,
    progress: 6,
    maxProgress: 10,
    rarity: "epic",
    xpReward: 300
  },
  
  // Special Badges
  {
    id: "math_genius",
    name: "Math Genius",
    description: "Master mathematics topics",
    icon: Calculator,
    category: "special",
    requirement: "Complete 20 math quizzes with 80%+ average",
    earned: false,
    progress: 8,
    maxProgress: 20,
    rarity: "legendary",
    xpReward: 1000
  },
  {
    id: "science_explorer",
    name: "Science Explorer",
    description: "Explore the wonders of science",
    icon: Lightbulb,
    category: "special",
    requirement: "Complete 15 science quizzes",
    earned: false,
    progress: 5,
    maxProgress: 15,
    rarity: "rare",
    xpReward: 400
  },
  {
    id: "speed_demon",
    name: "Speed Demon",
    description: "Complete quiz in under 2 minutes",
    icon: Timer,
    category: "special",
    requirement: "Complete any quiz in under 2 minutes",
    earned: false,
    rarity: "epic",
    xpReward: 250
  },
  {
    id: "bookworm",
    name: "Bookworm",
    description: "Read all help articles",
    icon: BookOpen,
    category: "special",
    requirement: "Read 10 help articles",
    earned: false,
    progress: 3,
    maxProgress: 10,
    rarity: "rare",
    xpReward: 150
  }
];

export function BadgesPage({ onBack }: BadgesPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [filteredBadges, setFilteredBadges] = useState(allBadges);

  const categories = [
    { id: "all", label: "All Badges", icon: Award },
    { id: "achievement", label: "Achievements", icon: Trophy },
    { id: "milestone", label: "Milestones", icon: Crown },
    { id: "streak", label: "Streaks", icon: Flame },
    { id: "special", label: "Special", icon: Sparkles }
  ];

  useEffect(() => {
    if (selectedCategory === "all") {
      setFilteredBadges(allBadges);
    } else {
      setFilteredBadges(allBadges.filter(badge => badge.category === selectedCategory));
    }
  }, [selectedCategory]);

  const earnedBadges = allBadges.filter(badge => badge.earned);
  const totalBadges = allBadges.length;
  const completionPercentage = (earnedBadges.length / totalBadges) * 100;

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "bg-gray-500";
      case "rare": return "bg-blue-500";
      case "epic": return "bg-purple-500";
      case "legendary": return "bg-yellow-500";
      default: return "bg-gray-500";
    }
  };

  const getRarityGlow = (rarity: string) => {
    switch (rarity) {
      case "common": return "shadow-lg";
      case "rare": return "shadow-lg shadow-blue-200";
      case "epic": return "shadow-lg shadow-purple-200";
      case "legendary": return "shadow-lg shadow-yellow-200";
      default: return "shadow-lg";
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <Home className="h-4 w-4" />
          Back to Dashboard
        </Button>
        <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
          Badge Collection
        </h1>
        <div className="w-24" />
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100">Total Badges</p>
                <p className="text-3xl font-bold">{earnedBadges.length}/{totalBadges}</p>
              </div>
              <Trophy className="h-12 w-12 text-purple-200" />
            </div>
            <div className="mt-4">
              <Progress value={completionPercentage} className="h-2" />
              <p className="text-sm text-purple-100 mt-1">{completionPercentage.toFixed(1)}% Complete</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground">Rarest Badge</p>
                <p className="text-xl font-bold">Perfect Scholar</p>
              </div>
              <div className="h-12 w-12 bg-yellow-500 rounded-full flex items-center justify-center">
                <Target className="h-6 w-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground">XP from Badges</p>
                <p className="text-xl font-bold">
                  {earnedBadges.reduce((total, badge) => total + badge.xpReward, 0)} XP
                </p>
              </div>
              <Zap className="h-12 w-12 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 mb-8">
        {categories.map((category) => {
          const IconComponent = category.icon;
          return (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className="flex items-center gap-2"
            >
              <IconComponent className="h-4 w-4" />
              {category.label}
            </Button>
          );
        })}
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBadges.map((badge) => {
          const IconComponent = badge.icon;
          const rarityColor = getRarityColor(badge.rarity);
          const rarityGlow = getRarityGlow(badge.rarity);
          
          return (
            <motion.div
              key={badge.id}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Card className={`relative overflow-hidden ${rarityGlow} ${
                badge.earned ? "border-green-400" : "border-gray-200"
              }`}>
                {badge.earned && (
                  <div className="absolute top-3 right-3">
                    <div className="bg-green-500 rounded-full p-1">
                      <Check className="h-4 w-4 text-white" />
                    </div>
                  </div>
                )}
                
                <CardHeader className="text-center pb-2">
                  <div className={`w-20 h-20 mx-auto rounded-full ${rarityColor} flex items-center justify-center mb-4 ${
                    badge.earned ? "" : "opacity-50"
                  }`}>
                    <IconComponent className="h-10 w-10 text-white" />
                  </div>
                  <CardTitle className={`text-lg ${badge.earned ? "" : "text-gray-500"}`}>
                    {badge.name}
                  </CardTitle>
                  <Badge className={`${rarityColor} text-white capitalize`}>
                    {badge.rarity}
                  </Badge>
                </CardHeader>
                
                <CardContent className="text-center">
                  <p className={`text-sm mb-3 ${badge.earned ? "text-gray-700" : "text-gray-500"}`}>
                    {badge.description}
                  </p>
                  
                  <p className="text-xs text-muted-foreground mb-3">
                    {badge.requirement}
                  </p>
                  
                  {badge.progress !== undefined && badge.maxProgress && !badge.earned && (
                    <div className="mb-3">
                      <Progress 
                        value={(badge.progress / badge.maxProgress) * 100} 
                        className="h-2 mb-1" 
                      />
                      <p className="text-xs text-muted-foreground">
                        {badge.progress} / {badge.maxProgress}
                      </p>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-yellow-600 font-medium">
                      +{badge.xpReward} XP
                    </span>
                    {badge.earnedDate && (
                      <span className="text-green-600 text-xs">
                        Earned {badge.earnedDate}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filteredBadges.length === 0 && (
        <div className="text-center py-12">
          <Medal className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">No badges in this category</h3>
          <p className="text-gray-500">Complete more activities to earn badges!</p>
        </div>
      )}
    </div>
  );
}