import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Search, 
  BookOpen, 
  Video, 
  MessageSquare, 
  Phone,
  Mail,
  Download,
  ExternalLink,
  Play,
  FileText,
  Users,
  HelpCircle,
  CheckCircle,
  Star,
  Gamepad2,
  Trophy,
  UserCheck,
  Heart
} from "lucide-react";
import { motion } from "motion/react";

interface HelpPageProps {
  onBack: () => void;
  onContact: () => void;
}

const faqCategories = [
  {
    id: "getting-started",
    title: "Getting Started",
    icon: BookOpen,
    questions: [
      {
        question: "How do I create an account?",
        answer: "Simply click 'Start Learning Now' on the homepage and follow the guided setup process. You can sign up with your email or social media accounts."
      },
      {
        question: "Is EduSpark free to use?",
        answer: "Yes! EduSpark offers a comprehensive free tier with access to all basic features including quizzes, progress tracking, and achievements. Premium features are available for schools and advanced users."
      },
      {
        question: "What age groups is EduSpark suitable for?",
        answer: "EduSpark is designed for learners of all ages, from elementary school students to adults. Our adaptive difficulty system ensures content is appropriate for each user's level."
      },
      {
        question: "Can I use EduSpark offline?",
        answer: "Yes! Our offline quiz mode allows you to download quizzes and continue learning even without an internet connection. Your progress will sync when you're back online."
      }
    ]
  },
  {
    id: "gamification",
    title: "Gamification & Rewards",
    icon: Gamepad2,
    questions: [
      {
        question: "How do XP and levels work?",
        answer: "You earn XP (Experience Points) by completing quizzes, maintaining streaks, and achieving high accuracy. As you accumulate XP, you level up and unlock new features and rewards."
      },
      {
        question: "What are achievements and how do I unlock them?",
        answer: "Achievements are special badges you earn for reaching milestones like perfect scores, study streaks, or completing quizzes in all subjects. Check the Achievements page to see all available badges."
      },
      {
        question: "How does the streak system work?",
        answer: "Your streak increases each day you complete at least one quiz. Maintaining streaks earns bonus XP and unlocks special achievements. Don't worry if you miss a day - you can restart your streak anytime!"
      },
      {
        question: "What can I do with coins?",
        answer: "Coins can be used in our reward store to unlock themes, avatars, and special challenges. Family accounts can pool coins for family rewards like movie nights or outings."
      }
    ]
  },
  {
    id: "family",
    title: "Family Features",
    icon: Heart,
    questions: [
      {
        question: "How do I set up family tracking?",
        answer: "Parents can create a family account and invite family members. Each member keeps their individual progress while contributing to family goals and shared rewards."
      },
      {
        question: "Can I monitor my child's progress?",
        answer: "Yes! The Family Hub provides detailed insights into each member's learning journey, including accuracy, study time, strengths, and areas needing support."
      },
      {
        question: "Are there parental controls?",
        answer: "Absolutely. Parents can set study schedules, approve reward redemptions, and receive notifications about their children's progress and achievements."
      },
      {
        question: "How do family rewards work?",
        answer: "Family members pool their XP to unlock shared rewards like family outings, movie nights, or special privileges. This encourages collaborative learning and family bonding."
      }
    ]
  },
  {
    id: "teachers",
    title: "Teacher Tools",
    icon: UserCheck,
    questions: [
      {
        question: "How can teachers use EduSpark?",
        answer: "Teachers get access to a comprehensive dashboard to track student progress, create custom assignments, and identify students who need additional support."
      },
      {
        question: "Can I create custom quizzes?",
        answer: "Yes! Teachers can create custom quizzes tailored to their curriculum and assign them to specific students or classes with deadlines and completion tracking."
      },
      {
        question: "How do I add students to my class?",
        answer: "Teachers can generate class codes that students use to join, or send direct invitations via email. Student privacy is always protected with appropriate permissions."
      },
      {
        question: "What analytics are available?",
        answer: "The teacher dashboard provides detailed analytics on student performance, learning patterns, subject strengths/weaknesses, and progress over time."
      }
    ]
  }
];

const tutorials = [
  {
    title: "Getting Started with EduSpark",
    description: "Learn the basics of navigation, taking quizzes, and earning your first achievements",
    duration: "5 min",
    type: "video",
    thumbnail: "https://images.unsplash.com/photo-1653212883731-4d5bc66e0181?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b21lciUyMHN1cHBvcnQlMjBoZWxwJTIwZGVza3xlbnwxfHx8fDE3NTc3NzgzNzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    title: "Maximizing Your Learning with Gamification",
    description: "Discover how to use XP, achievements, and streaks to boost your motivation",
    duration: "7 min",
    type: "video",
    thumbnail: "https://images.unsplash.com/photo-1653212883731-4d5bc66e0181?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b21lciUyMHN1cHBvcnQlMjBoZWxwJTIwZGVza3xlbnwxfHx8fDE3NTc3NzgzNzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    title: "Setting Up Family Learning",
    description: "Create family accounts, set goals, and track everyone's progress together",
    duration: "8 min",
    type: "guide",
    thumbnail: "https://images.unsplash.com/photo-1653212883731-4d5bc66e0181?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b21lciUyMHN1cHBvcnQlMjBoZWxwJTIwZGVza3xlbnwxfHx8fDE3NTc3NzgzNzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  },
  {
    title: "Teacher Dashboard Walkthrough",
    description: "Complete guide to managing students and creating assignments",
    duration: "12 min",
    type: "video",
    thumbnail: "https://images.unsplash.com/photo-1653212883731-4d5bc66e0181?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b21lciUyMHN1cHBvcnQlMjBoZWxwJTIwZGVza3xlbnwxfHx8fDE3NTc3NzgzNzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
  }
];

const quickLinks = [
  { title: "Download Mobile App", icon: Download, description: "Get EduSpark on iOS and Android" },
  { title: "System Requirements", icon: FileText, description: "Check compatibility requirements" },
  { title: "Privacy Policy", icon: FileText, description: "Learn how we protect your data" },
  { title: "Terms of Service", icon: FileText, description: "Review our terms and conditions" },
  { title: "Community Forum", icon: MessageSquare, description: "Connect with other learners" },
  { title: "Feature Requests", icon: Star, description: "Suggest new features" }
];

export function HelpPage({ onBack, onContact }: HelpPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredFAQ = selectedCategory === "all" 
    ? faqCategories 
    : faqCategories.filter(cat => cat.id === selectedCategory);

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          How Can We Help You?
        </h1>
        <p className="text-xl text-muted-foreground mb-8">
          Find answers, get support, and learn how to make the most of EduSpark
        </p>
        
        {/* Search */}
        <div className="max-w-2xl mx-auto relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            placeholder="Search for help articles, tutorials, or FAQs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-14 text-lg"
          />
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer" onClick={onContact}>
          <CardContent className="p-6 text-center">
            <MessageSquare className="h-12 w-12 text-blue-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Contact Support</h3>
            <p className="text-muted-foreground">Get personalized help from our support team</p>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer">
          <CardContent className="p-6 text-center">
            <Video className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Video Tutorials</h3>
            <p className="text-muted-foreground">Watch step-by-step guides and walkthroughs</p>
          </CardContent>
        </Card>
        
        <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer">
          <CardContent className="p-6 text-center">
            <Users className="h-12 w-12 text-purple-500 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Community</h3>
            <p className="text-muted-foreground">Connect with other learners and educators</p>
          </CardContent>
        </Card>
      </div>

      {/* Video Tutorials */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Video Tutorials & Guides</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tutorials.map((tutorial, index) => (
            <motion.div
              key={tutorial.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer group">
                <div className="relative">
                  <ImageWithFallback
                    src={tutorial.thumbnail}
                    alt={tutorial.title}
                    className="w-full h-32 object-cover rounded-t-lg"
                  />
                  <div className="absolute inset-0 bg-black/40 rounded-t-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Play className="h-8 w-8 text-white" />
                  </div>
                  <Badge className="absolute top-2 right-2 bg-black/70 text-white">
                    {tutorial.duration}
                  </Badge>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    {tutorial.type === "video" ? (
                      <Video className="h-4 w-4 text-blue-500" />
                    ) : (
                      <FileText className="h-4 w-4 text-green-500" />
                    )}
                    <Badge variant="secondary">{tutorial.type}</Badge>
                  </div>
                  <h3 className="font-semibold mb-2">{tutorial.title}</h3>
                  <p className="text-sm text-muted-foreground">{tutorial.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* FAQ Section */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
          <div className="flex gap-2">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory("all")}
            >
              All
            </Button>
            {faqCategories.map((category) => {
              const IconComponent = category.icon;
              return (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="hidden md:flex items-center gap-2"
                >
                  <IconComponent className="h-3 w-3" />
                  {category.title}
                </Button>
              );
            })}
          </div>
        </div>

        <div className="space-y-8">
          {filteredFAQ.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card key={category.id}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <IconComponent className="h-5 w-5" />
                    {category.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {category.questions.map((faq, index) => (
                      <AccordionItem key={index} value={`${category.id}-${index}`}>
                        <AccordionTrigger className="text-left">
                          {faq.question}
                        </AccordionTrigger>
                        <AccordionContent className="text-muted-foreground">
                          {faq.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Quick Links */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Quick Links & Resources</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickLinks.map((link) => {
            const IconComponent = link.icon;
            return (
              <Card key={link.title} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4 flex items-center gap-3">
                  <IconComponent className="h-8 w-8 text-blue-500" />
                  <div>
                    <h3 className="font-semibold">{link.title}</h3>
                    <p className="text-sm text-muted-foreground">{link.description}</p>
                  </div>
                  <ExternalLink className="h-4 w-4 text-muted-foreground ml-auto" />
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Contact Section */}
      <section className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Still Need Help?</h2>
        <p className="text-muted-foreground mb-6">
          Our support team is here to help you succeed. Reach out through any of these channels:
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button onClick={onContact} className="flex items-center gap-2">
            <Mail className="h-4 w-4" />
            Email Support
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            Live Chat
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Phone className="h-4 w-4" />
            Schedule Call
          </Button>
        </div>
        <p className="text-sm text-muted-foreground mt-4">
          Typical response time: Within 2 hours during business hours
        </p>
      </section>
    </div>
  );
}