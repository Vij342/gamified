import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Trophy, 
  Star, 
  Target, 
  Zap, 
  Home, 
  RotateCcw,
  TrendingUp,
  Award,
  Flame
} from "lucide-react";
import { motion } from "motion/react";

interface QuizResultsProps {
  score: number;
  totalQuestions: number;
  xpEarned: number;
  subject: string;
  onRetakeQuiz: () => void;
  onBackToDashboard: () => void;
}

export function QuizResults({ 
  score, 
  totalQuestions, 
  xpEarned, 
  subject, 
  onRetakeQuiz, 
  onBackToDashboard 
}: QuizResultsProps) {
  const percentage = Math.round((score / totalQuestions) * 100);
  
  const getPerformanceLevel = () => {
    if (percentage >= 90) return { level: "Outstanding!", color: "text-yellow-600", bg: "bg-yellow-50", icon: Trophy };
    if (percentage >= 80) return { level: "Excellent!", color: "text-green-600", bg: "bg-green-50", icon: Award };
    if (percentage >= 70) return { level: "Good Job!", color: "text-blue-600", bg: "bg-blue-50", icon: Star };
    if (percentage >= 60) return { level: "Not Bad!", color: "text-purple-600", bg: "bg-purple-50", icon: Target };
    return { level: "Keep Trying!", color: "text-orange-600", bg: "bg-orange-50", icon: TrendingUp };
  };

  const performance = getPerformanceLevel();
  const PerformanceIcon = performance.icon;

  const achievements = [];
  if (percentage === 100) achievements.push({ name: "Perfect Score!", icon: Trophy, color: "text-yellow-600" });
  if (percentage >= 90) achievements.push({ name: "Quiz Master", icon: Award, color: "text-purple-600" });
  if (score >= 8) achievements.push({ name: "Knowledge Hunter", icon: Target, color: "text-blue-600" });
  if (xpEarned >= 150) achievements.push({ name: "XP Collector", icon: Flame, color: "text-orange-600" });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Card className="shadow-2xl border-0 overflow-hidden">
            {/* Header */}
            <CardHeader className={`${performance.bg} text-center py-8`}>
              <motion.div
                initial={{ y: -20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="flex flex-col items-center space-y-4"
              >
                <div className="relative">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    className="absolute inset-0 border-4 border-dashed border-current opacity-20 rounded-full"
                  ></motion.div>
                  <div className={`p-6 rounded-full ${performance.color} bg-white/80`}>
                    <PerformanceIcon className="h-12 w-12" />
                  </div>
                </div>
                
                <CardTitle className={`text-3xl ${performance.color}`}>
                  {performance.level}
                </CardTitle>
                
                <p className="text-lg text-muted-foreground">
                  Quiz completed in {subject}
                </p>
              </motion.div>
            </CardHeader>

            <CardContent className="p-8">
              {/* Score Display */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-center mb-8"
              >
                <div className="flex items-center justify-center space-x-8 mb-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-primary mb-2">
                      {score}/{totalQuestions}
                    </div>
                    <p className="text-sm text-muted-foreground">Correct Answers</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-4xl font-bold text-green-600 mb-2">
                      {percentage}%
                    </div>
                    <p className="text-sm text-muted-foreground">Accuracy</p>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-4xl font-bold text-purple-600 mb-2 flex items-center justify-center">
                      +{xpEarned}
                      <Zap className="h-6 w-6 ml-1 text-yellow-500" />
                    </div>
                    <p className="text-sm text-muted-foreground">XP Earned</p>
                  </div>
                </div>
              </motion.div>

              {/* Achievements */}
              {achievements.length > 0 && (
                <motion.div
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="mb-8"
                >
                  <h3 className="text-xl font-semibold mb-4 text-center">New Achievements! 🎉</h3>
                  <div className="flex flex-wrap justify-center gap-3">
                    {achievements.map((achievement, index) => {
                      const AchievementIcon = achievement.icon;
                      return (
                        <motion.div
                          key={achievement.name}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: 0.5 + index * 0.1, type: "spring" }}
                        >
                          <Badge className="flex items-center gap-2 px-4 py-2 text-sm bg-gradient-to-r from-yellow-400 to-orange-400 text-white">
                            <AchievementIcon className="h-4 w-4" />
                            {achievement.name}
                          </Badge>
                        </motion.div>
                      );
                    })}
                  </div>
                </motion.div>
              )}

              {/* Performance Image */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="text-center mb-8"
              >
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1693891156257-dd6e94199a20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnYW1lJTIwYWNoaWV2ZW1lbnQlMjB0cm9waHklMjBiYWRnZXxlbnwxfHx8fDE3NTc3Nzc5ODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Achievement celebration"
                  className="w-48 h-32 object-cover rounded-lg mx-auto opacity-80"
                />
              </motion.div>

              {/* Action Buttons */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="flex flex-col sm:flex-row gap-4 justify-center"
              >
                <Button
                  onClick={onBackToDashboard}
                  className="flex items-center gap-2 px-8 py-3"
                  size="lg"
                >
                  <Home className="h-5 w-5" />
                  Back to Dashboard
                </Button>
                
                <Button
                  onClick={onRetakeQuiz}
                  variant="outline" 
                  className="flex items-center gap-2 px-8 py-3"
                  size="lg"
                >
                  <RotateCcw className="h-5 w-5" />
                  Retake Quiz
                </Button>
              </motion.div>

              {/* Motivational Message */}
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="text-center mt-8 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg"
              >
                <p className="text-muted-foreground">
                  {percentage === 100 
                    ? "Perfect! You've mastered this topic! 🌟"
                    : percentage >= 80
                    ? "Great work! You're really getting the hang of this! 🚀"
                    : percentage >= 60
                    ? "Good effort! Practice makes perfect. Keep going! 💪"
                    : "Don't give up! Every mistake is a learning opportunity! 📚"
                  }
                </p>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}