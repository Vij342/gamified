import { Button } from "./ui/button";
import { 
  Home, 
  GraduationCap, 
  Trophy, 
  Star,
  Users,
  UserCheck,
  HelpCircle,
  Mail,
  Menu,
  X,
  Award
} from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

type AppState = "home" | "dashboard" | "multilingualDashboard" | "achievements" | "leaderboard" | "badges" | "teacher" | "family" | "help" | "contact";

interface NavigationProps {
  currentState: AppState;
  onNavigate: (state: AppState) => void;
}

export function Navigation({ currentState, onNavigate }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems = [
    { id: "home" as AppState, label: "Home", icon: Home },
    { id: "dashboard" as AppState, label: "Learn", icon: GraduationCap },
    { id: "achievements" as AppState, label: "Achievements", icon: Star },
    { id: "leaderboard" as AppState, label: "Leaderboard", icon: Trophy },
    { id: "badges" as AppState, label: "Badges", icon: Award },
    { id: "teacher" as AppState, label: "Teachers", icon: UserCheck },
    { id: "family" as AppState, label: "Family", icon: Users },
    { id: "help" as AppState, label: "Help", icon: HelpCircle },
    { id: "contact" as AppState, label: "Contact", icon: Mail }
  ];

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex items-center space-x-1">
        {navigationItems.map((item) => {
          const IconComponent = item.icon;
          return (
            <Button
              key={item.id}
              variant={currentState === item.id ? "secondary" : "ghost"}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center gap-2 text-white hover:bg-white/20 ${
                currentState === item.id ? "bg-white/20" : ""
              }`}
            >
              <IconComponent className="h-4 w-4" />
              <span className="hidden lg:inline">{item.label}</span>
            </Button>
          );
        })}
      </nav>

      {/* Mobile Navigation */}
      <div className="md:hidden">
        <Button
          variant="ghost"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="text-white hover:bg-white/20"
        >
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>

        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full left-0 right-0 bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg z-50"
            >
              <div className="p-4 grid grid-cols-2 gap-2">
                {navigationItems.map((item) => {
                  const IconComponent = item.icon;
                  return (
                    <Button
                      key={item.id}
                      variant={currentState === item.id ? "secondary" : "ghost"}
                      onClick={() => {
                        onNavigate(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`flex items-center gap-2 text-white hover:bg-white/20 justify-start ${
                        currentState === item.id ? "bg-white/20" : ""
                      }`}
                    >
                      <IconComponent className="h-4 w-4" />
                      {item.label}
                    </Button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
}