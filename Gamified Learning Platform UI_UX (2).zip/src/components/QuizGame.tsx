import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { 
  Clock, 
  Zap, 
  CheckCircle, 
  XCircle, 
  ArrowLeft,
  Brain,
  Target,
  Flame
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: "easy" | "medium" | "hard";
}

interface QuizGameProps {
  subjectId: string;
  onBack: () => void;
  onComplete: (score: number, xpEarned: number) => void;
}

const sampleQuestions: Record<string, Question[]> = {
  math: [
    {
      id: "1",
      question: "What is 15 × 8?",
      options: ["110", "120", "130", "140"],
      correctAnswer: 1,
      explanation: "15 × 8 = 120. You can think of it as (10 × 8) + (5 × 8) = 80 + 40 = 120",
      difficulty: "easy"
    },
    {
      id: "2", 
      question: "If a triangle has angles of 60° and 80°, what is the third angle?",
      options: ["30°", "40°", "50°", "60°"],
      correctAnswer: 1,
      explanation: "The sum of angles in a triangle is 180°. So 180° - 60° - 80° = 40°",
      difficulty: "medium"
    },
    {
      id: "3",
      question: "What is the square root of 144?",
      options: ["10", "11", "12", "13"],
      correctAnswer: 2,
      explanation: "12 × 12 = 144, so √144 = 12",
      difficulty: "easy"
    }
  ],
  science: [
    {
      id: "1",
      question: "What is the chemical symbol for gold?",
      options: ["Go", "Gd", "Au", "Ag"],
      correctAnswer: 2,
      explanation: "Au comes from the Latin word 'aurum' meaning gold",
      difficulty: "easy"
    },
    {
      id: "2",
      question: "Which planet is known as the Red Planet?",
      options: ["Venus", "Mars", "Jupiter", "Saturn"],
      correctAnswer: 1,
      explanation: "Mars appears red due to iron oxide (rust) on its surface",
      difficulty: "easy"
    }
  ],
  english: [
    {
      id: "1",
      question: "Which word is a synonym for 'happy'?",
      options: ["Sad", "Joyful", "Angry", "Tired"],
      correctAnswer: 1,
      explanation: "Joyful means feeling great pleasure and happiness",
      difficulty: "easy"
    }
  ]
};

export function QuizGame({ subjectId, onBack, onComplete }: QuizGameProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [streak, setStreak] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [questions] = useState(sampleQuestions[subjectId] || sampleQuestions.math);

  useEffect(() => {
    if (timeLeft > 0 && !isAnswered) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !isAnswered) {
      handleAnswer(-1); // Time's up
    }
  }, [timeLeft, isAnswered]);

  const handleAnswer = (answerIndex: number) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answerIndex);
    setIsAnswered(true);
    
    const isCorrect = answerIndex === questions[currentQuestion].correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
      setStreak(streak + 1);
    } else {
      setStreak(0);
    }
    
    setShowResult(true);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setIsAnswered(false);
      setTimeLeft(30);
    } else {
      // Quiz complete
      const finalScore = score + (selectedAnswer === questions[currentQuestion].correctAnswer ? 1 : 0);
      const xpEarned = Math.round((finalScore / questions.length) * 100 + streak * 10);
      onComplete(finalScore, xpEarned);
    }
  };

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const isCorrect = selectedAnswer === currentQ.correctAnswer;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Brain className="h-3 w-3" />
              Question {currentQuestion + 1}/{questions.length}
            </Badge>
            
            <Badge variant="secondary" className="flex items-center gap-1">
              <Target className="h-3 w-3" />
              Score: {score}/{questions.length}
            </Badge>
            
            {streak > 0 && (
              <Badge className="bg-orange-500 flex items-center gap-1">
                <Flame className="h-3 w-3" />
                Streak: {streak}
              </Badge>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-6">
          <Progress value={progress} className="h-3" />
        </div>

        {/* Quiz Card */}
        <Card className="shadow-xl border-0">
          <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-t-lg">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Quiz Challenge</CardTitle>
              <div className="flex items-center gap-4">
                <Badge 
                  className={`${
                    currentQ.difficulty === 'easy' ? 'bg-green-500' :
                    currentQ.difficulty === 'medium' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                >
                  {currentQ.difficulty}
                </Badge>
                
                <div className="flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full">
                  <Clock className="h-4 w-4" />
                  <span className={`font-bold ${timeLeft <= 10 ? 'text-red-300' : ''}`}>
                    {timeLeft}s
                  </span>
                </div>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="text-2xl font-semibold mb-8 text-center">
                  {currentQ.question}
                </h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  {currentQ.options.map((option, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ scale: isAnswered ? 1 : 1.02 }}
                      whileTap={{ scale: isAnswered ? 1 : 0.98 }}
                    >
                      <Button
                        variant={
                          showResult
                            ? index === currentQ.correctAnswer
                              ? "default"
                              : index === selectedAnswer
                              ? "destructive"
                              : "outline"
                            : selectedAnswer === index
                            ? "default"
                            : "outline"
                        }
                        className={`w-full p-6 h-auto text-left justify-start text-wrap ${
                          showResult && index === currentQ.correctAnswer
                            ? "bg-green-500 hover:bg-green-600 border-green-500"
                            : showResult && index === selectedAnswer && !isCorrect
                            ? "bg-red-500 hover:bg-red-600 border-red-500"
                            : ""
                        }`}
                        onClick={() => handleAnswer(index)}
                        disabled={isAnswered}
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex-shrink-0 w-8 h-8 rounded-full bg-current opacity-20 flex items-center justify-center">
                            <span className="font-bold text-current opacity-100">
                              {String.fromCharCode(65 + index)}
                            </span>
                          </div>
                          <span>{option}</span>
                          
                          {showResult && index === currentQ.correctAnswer && (
                            <CheckCircle className="h-5 w-5 ml-auto text-white" />
                          )}
                          {showResult && index === selectedAnswer && !isCorrect && (
                            <XCircle className="h-5 w-5 ml-auto text-white" />
                          )}
                        </div>
                      </Button>
                    </motion.div>
                  ))}
                </div>

                {showResult && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`p-4 rounded-lg mb-6 ${
                      isCorrect ? "bg-green-50 border border-green-200" : "bg-red-50 border border-red-200"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      {isCorrect ? (
                        <CheckCircle className="h-5 w-5 text-green-600" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-600" />
                      )}
                      <span className={`font-semibold ${isCorrect ? "text-green-800" : "text-red-800"}`}>
                        {isCorrect ? "Correct!" : "Incorrect"}
                      </span>
                      {isCorrect && streak > 1 && (
                        <Badge className="bg-orange-500 ml-2">
                          <Flame className="h-3 w-3 mr-1" />
                          {streak} in a row!
                        </Badge>
                      )}
                    </div>
                    <p className={isCorrect ? "text-green-700" : "text-red-700"}>
                      {currentQ.explanation}
                    </p>
                  </motion.div>
                )}

                {showResult && (
                  <div className="text-center">
                    <Button onClick={nextQuestion} size="lg" className="min-w-32">
                      {currentQuestion < questions.length - 1 ? "Next Question" : "Finish Quiz"}
                      <Zap className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}