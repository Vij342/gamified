import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { motion } from "motion/react";

interface StudentLoginProps {
  language: string;
  onLogin: (name: string, grade: number, deviceId: string) => void;
  onBack: () => void;
}

export function StudentLogin({ language, onLogin, onBack }: StudentLoginProps) {
  const [studentName, setStudentName] = useState("");
  const [selectedGrade, setSelectedGrade] = useState<string>("");
  const [deviceId, setDeviceId] = useState("");

  // Generate device ID on component mount
  useEffect(() => {
    const generateDeviceId = () => {
      const prefix = "EDU";
      const timestamp = Date.now().toString().slice(-6);
      const random = Math.random().toString(36).substring(2, 8).toUpperCase();
      return `${prefix}-${timestamp}-${random}`;
    };

    setDeviceId(generateDeviceId());
  }, []);

  const grades = Array.from({ length: 7 }, (_, i) => i + 6); // Grades 6-12

  const handleStartLearning = () => {
    if (studentName.trim() && selectedGrade) {
      onLogin(studentName.trim(), parseInt(selectedGrade), deviceId);
    }
  };

  const getLanguageText = (key: string) => {
    const texts: Record<string, Record<string, string>> = {
      en: {
        title: "Student Login",
        nameLabel: "Enter Your Name",
        namePlaceholder: "Your full name",
        deviceIdLabel: "Device ID",
        gradeLabel: "Grade",
        gradePlaceholder: "Select your grade",
        startButton: "Start Learning",
        backButton: "Back"
      },
      hi: {
        title: "छात्र लॉगिन",
        nameLabel: "अपना नाम दर्ज करें",
        namePlaceholder: "आपका पूरा नाम",
        deviceIdLabel: "डिवाइस आईडी",
        gradeLabel: "कक्षा",
        gradePlaceholder: "अपनी कक्षा चुनें",
        startButton: "सीखना शुरू करें",
        backButton: "वापस"
      }
    };
    return texts[language]?.[key] || texts.en[key];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-500 via-blue-600 to-purple-600 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 max-w-md w-full shadow-2xl"
      >
        {/* Header */}
        <motion.div 
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-8"
        >
          <div className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent mb-4">
            <h1 className="text-3xl font-bold">{getLanguageText("title")}</h1>
          </div>
          <div className="text-4xl mb-2">👨‍🎓</div>
        </motion.div>

        {/* Form */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="space-y-6"
        >
          {/* Student Name */}
          <div>
            <label className="block text-gray-700 mb-2">
              {getLanguageText("nameLabel")}
            </label>
            <Input
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              placeholder={getLanguageText("namePlaceholder")}
              className="h-12 text-lg bg-gray-50 border-2 border-gray-200 rounded-xl"
            />
          </div>

          {/* Device ID (Read-only) */}
          <div>
            <label className="block text-gray-700 mb-2">
              {getLanguageText("deviceIdLabel")}
            </label>
            <div className="h-12 px-3 bg-gray-100 border-2 border-gray-200 rounded-xl flex items-center">
              <span className="text-gray-600 font-mono">{deviceId}</span>
              <div className="ml-auto text-green-500">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  ✓
                </motion.div>
              </div>
            </div>
          </div>

          {/* Grade Selection */}
          <div>
            <label className="block text-gray-700 mb-2">
              {getLanguageText("gradeLabel")}
            </label>
            <Select value={selectedGrade} onValueChange={setSelectedGrade}>
              <SelectTrigger className="w-full h-12 text-lg bg-gray-50 border-2 border-gray-200 rounded-xl">
                <SelectValue placeholder={getLanguageText("gradePlaceholder")} />
              </SelectTrigger>
              <SelectContent>
                {grades.map((grade) => (
                  <SelectItem key={grade} value={grade.toString()} className="text-lg py-2">
                    Class {grade}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Buttons */}
          <div className="space-y-3">
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                onClick={handleStartLearning}
                disabled={!studentName.trim() || !selectedGrade}
                className="w-full h-12 text-lg bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg"
              >
                {getLanguageText("startButton")}
                <motion.span
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="ml-2"
                >
                  🚀
                </motion.span>
              </Button>
            </motion.div>

            <Button
              onClick={onBack}
              variant="outline"
              className="w-full h-12 text-lg border-2 rounded-xl"
            >
              ← {getLanguageText("backButton")}
            </Button>
          </div>
        </motion.div>

        {/* Fun Animation Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{ 
              y: [0, -15, 0],
              rotate: [0, 10, -10, 0]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="absolute top-8 right-8 text-2xl opacity-20"
          >
            🎯
          </motion.div>
          <motion.div
            animate={{ 
              y: [0, 15, 0],
              rotate: [0, -10, 10, 0]
            }}
            transition={{ 
              duration: 5, 
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1.5
            }}
            className="absolute bottom-8 left-8 text-2xl opacity-20"
          >
            📖
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}