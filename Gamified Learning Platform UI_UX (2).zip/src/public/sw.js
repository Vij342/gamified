// EduSpark Service Worker for Offline Functionality
const CACHE_NAME = 'eduspark-v1.0.0';
const STATIC_CACHE = 'eduspark-static-v1.0.0';
const DYNAMIC_CACHE = 'eduspark-dynamic-v1.0.0';

// Files to cache for offline use
const STATIC_FILES = [
  '/',
  '/index.html',
  '/App.tsx',
  '/styles/globals.css',
  '/components/Dashboard.tsx',
  '/components/QuizGame.tsx',
  '/components/QuizResults.tsx',
  '/components/Achievements.tsx',
  '/components/Leaderboard.tsx',
  '/components/Header.tsx',
  '/components/Navigation.tsx',
  '/components/HomePage.tsx',
  '/components/TeacherTracking.tsx',
  '/components/FamilyTracking.tsx',
  '/components/HelpPage.tsx',
  '/components/ContactPage.tsx',
  // Add any other critical assets
  '/manifest.json'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
  console.log('[SW] Installing Service Worker');
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => {
        console.log('[SW] Caching static files');
        return cache.addAll(STATIC_FILES);
      })
      .catch((error) => {
        console.error('[SW] Failed to cache static files:', error);
      })
  );
  // Force the waiting service worker to become the active service worker
  self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating Service Worker');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
            console.log('[SW] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  // Ensure the service worker takes control immediately
  return self.clients.claim();
});

// Fetch event - serve from cache when offline
self.addEventListener('fetch', (event) => {
  // Skip non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // Skip chrome-extension and other non-http requests
  if (!event.request.url.startsWith('http')) {
    return;
  }

  event.respondWith(
    caches.match(event.request)
      .then((cachedResponse) => {
        // Return cached version if available
        if (cachedResponse) {
          console.log('[SW] Serving from cache:', event.request.url);
          return cachedResponse;
        }

        // Otherwise, fetch from network
        return fetch(event.request)
          .then((networkResponse) => {
            // Don't cache non-successful responses
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }

            // Clone the response since it can only be consumed once
            const responseToCache = networkResponse.clone();

            // Cache dynamic content (images, API responses, etc.)
            if (shouldCacheDynamically(event.request)) {
              caches.open(DYNAMIC_CACHE)
                .then((cache) => {
                  console.log('[SW] Caching dynamic content:', event.request.url);
                  cache.put(event.request, responseToCache);
                });
            }

            return networkResponse;
          })
          .catch(() => {
            // Network failed, try to serve offline fallback
            if (event.request.destination === 'document') {
              return caches.match('/index.html');
            }
            
            // For images, return a placeholder if needed
            if (event.request.destination === 'image') {
              return new Response(
                '<svg width="200" height="200" xmlns="http://www.w3.org/2000/svg"><rect width="200" height="200" fill="#f0f0f0"/><text x="50%" y="50%" text-anchor="middle" dy=".3em" fill="#999">Offline</text></svg>',
                { headers: { 'Content-Type': 'image/svg+xml' } }
              );
            }
          });
      })
  );
});

// Helper function to determine if content should be cached dynamically
function shouldCacheDynamically(request) {
  const url = request.url;
  
  // Cache images
  if (request.destination === 'image') {
    return true;
  }
  
  // Cache external resources (fonts, libraries, etc.)
  if (url.includes('fonts.googleapis.com') || 
      url.includes('unpkg.com') || 
      url.includes('jsdelivr.net') ||
      url.includes('unsplash.com')) {
    return true;
  }
  
  // Don't cache everything else by default
  return false;
}

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync triggered:', event.tag);
  
  if (event.tag === 'quiz-submission') {
    event.waitUntil(syncQuizData());
  }
  
  if (event.tag === 'user-progress') {
    event.waitUntil(syncUserProgress());
  }
});

// Sync quiz data when back online
async function syncQuizData() {
  try {
    // Get pending quiz submissions from IndexedDB or localStorage
    const pendingQuizzes = JSON.parse(localStorage.getItem('pending-quizzes') || '[]');
    
    for (const quiz of pendingQuizzes) {
      // In a real app, you'd send this to your server
      console.log('[SW] Syncing quiz data:', quiz);
      // Remove from pending after successful sync
    }
    
    // Clear pending quizzes after sync
    localStorage.removeItem('pending-quizzes');
    console.log('[SW] Quiz data sync completed');
  } catch (error) {
    console.error('[SW] Failed to sync quiz data:', error);
  }
}

// Sync user progress when back online
async function syncUserProgress() {
  try {
    const userProgress = JSON.parse(localStorage.getItem('eduspark-user') || '{}');
    // In a real app, you'd send this to your server
    console.log('[SW] Syncing user progress:', userProgress);
  } catch (error) {
    console.error('[SW] Failed to sync user progress:', error);
  }
}

// Push notification handling (for future features)
self.addEventListener('push', (event) => {
  console.log('[SW] Push message received');
  
  const options = {
    body: event.data ? event.data.text() : 'New quiz available!',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/badge-72x72.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    },
    actions: [
      {
        action: 'explore',
        title: 'Start Quiz',
        icon: '/icons/checkmark.png'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/icons/xmark.png'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('EduSpark', options)
  );
});

// Handle notification clicks
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification click received');
  
  event.notification.close();
  
  if (event.action === 'explore') {
    event.waitUntil(
      clients.openWindow('/dashboard')
    );
  }
});

// Handle messages from the main thread
self.addEventListener('message', (event) => {
  console.log('[SW] Message received:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({ version: CACHE_NAME });
  }
});