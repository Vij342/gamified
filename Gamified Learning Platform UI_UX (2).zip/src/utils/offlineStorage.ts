// Enhanced offline storage utilities for EduSpark

interface QuizSubmission {
  id: string;
  timestamp: number;
  subject: string;
  score: number;
  totalQuestions: number;
  xpEarned: number;
  timeSpent: number;
  answers: Array<{
    questionId: string;
    selectedAnswer: string;
    isCorrect: boolean;
  }>;
}

interface UserProgress {
  userId: string;
  lastUpdated: number;
  level: number;
  xp: number;
  coins: number;
  streak: number;
  achievements: string[];
  completedQuizzes: number;
  subjectProgress: Record<string, {
    totalQuizzes: number;
    averageScore: number;
    bestScore: number;
    totalXP: number;
  }>;
}

interface OfflineAction {
  id: string;
  type: 'quiz-submission' | 'progress-update' | 'achievement-unlock';
  timestamp: number;
  data: any;
  retryCount: number;
}

class OfflineStorageManager {
  private dbName = 'EduSparkDB';
  private dbVersion = 1;
  private db: IDBDatabase | null = null;

  // Initialize IndexedDB
  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create object stores
        if (!db.objectStoreNames.contains('quizSubmissions')) {
          const quizStore = db.createObjectStore('quizSubmissions', { keyPath: 'id' });
          quizStore.createIndex('timestamp', 'timestamp', { unique: false });
          quizStore.createIndex('subject', 'subject', { unique: false });
        }

        if (!db.objectStoreNames.contains('userProgress')) {
          db.createObjectStore('userProgress', { keyPath: 'userId' });
        }

        if (!db.objectStoreNames.contains('offlineActions')) {
          const actionStore = db.createObjectStore('offlineActions', { keyPath: 'id' });
          actionStore.createIndex('timestamp', 'timestamp', { unique: false });
          actionStore.createIndex('type', 'type', { unique: false });
        }

        if (!db.objectStoreNames.contains('quizData')) {
          const quizDataStore = db.createObjectStore('quizData', { keyPath: 'subject' });
          quizDataStore.createIndex('lastUpdated', 'lastUpdated', { unique: false });
        }
      };
    });
  }

  // Save quiz submission for offline sync
  async saveQuizSubmission(submission: QuizSubmission): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['quizSubmissions'], 'readwrite');
      const store = transaction.objectStore('quizSubmissions');
      
      const request = store.add(submission);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Get pending quiz submissions
  async getPendingQuizSubmissions(): Promise<QuizSubmission[]> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['quizSubmissions'], 'readonly');
      const store = transaction.objectStore('quizSubmissions');
      
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Save user progress
  async saveUserProgress(progress: UserProgress): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['userProgress'], 'readwrite');
      const store = transaction.objectStore('userProgress');
      
      const request = store.put(progress);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Get user progress
  async getUserProgress(userId: string): Promise<UserProgress | null> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['userProgress'], 'readonly');
      const store = transaction.objectStore('userProgress');
      
      const request = store.get(userId);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  // Save offline action for later sync
  async saveOfflineAction(action: OfflineAction): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['offlineActions'], 'readwrite');
      const store = transaction.objectStore('offlineActions');
      
      const request = store.add(action);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Get pending offline actions
  async getPendingOfflineActions(): Promise<OfflineAction[]> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['offlineActions'], 'readonly');
      const store = transaction.objectStore('offlineActions');
      
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Remove synced offline action
  async removeOfflineAction(actionId: string): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['offlineActions'], 'readwrite');
      const store = transaction.objectStore('offlineActions');
      
      const request = store.delete(actionId);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Cache quiz data for offline use
  async cacheQuizData(subject: string, quizData: any): Promise<void> {
    if (!this.db) await this.init();

    const data = {
      subject,
      ...quizData,
      lastUpdated: Date.now()
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['quizData'], 'readwrite');
      const store = transaction.objectStore('quizData');
      
      const request = store.put(data);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  // Get cached quiz data
  async getCachedQuizData(subject: string): Promise<any> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(['quizData'], 'readonly');
      const store = transaction.objectStore('quizData');
      
      const request = store.get(subject);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  // Clear all data (for reset/logout)
  async clearAllData(): Promise<void> {
    if (!this.db) await this.init();

    const storeNames = ['quizSubmissions', 'userProgress', 'offlineActions', 'quizData'];
    
    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction(storeNames, 'readwrite');
      
      let completedStores = 0;
      const totalStores = storeNames.length;
      
      storeNames.forEach(storeName => {
        const store = transaction.objectStore(storeName);
        const request = store.clear();
        
        request.onsuccess = () => {
          completedStores++;
          if (completedStores === totalStores) {
            resolve();
          }
        };
        
        request.onerror = () => reject(request.error);
      });
    });
  }
}

// Singleton instance
const offlineStorage = new OfflineStorageManager();

// Helper functions for easy use
export const saveQuizOffline = async (
  subjectId: string,
  score: number,
  totalQuestions: number,
  xpEarned: number,
  answers: any[]
): Promise<void> => {
  const submission: QuizSubmission = {
    id: `quiz_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    timestamp: Date.now(),
    subject: subjectId,
    score,
    totalQuestions,
    xpEarned,
    timeSpent: 0, // Would be calculated in real implementation
    answers: answers.map((answer, index) => ({
      questionId: `q_${index}`,
      selectedAnswer: answer.selected,
      isCorrect: answer.correct
    }))
  };

  await offlineStorage.saveQuizSubmission(submission);
  
  // Also save as offline action for sync
  await offlineStorage.saveOfflineAction({
    id: `action_${submission.id}`,
    type: 'quiz-submission',
    timestamp: Date.now(),
    data: submission,
    retryCount: 0
  });
};

export const saveUserProgressOffline = async (userData: any): Promise<void> => {
  const progress: UserProgress = {
    userId: 'current_user', // In real app, this would be the actual user ID
    lastUpdated: Date.now(),
    level: userData.level,
    xp: userData.xp,
    coins: userData.coins,
    streak: userData.streak,
    achievements: userData.achievements || [],
    completedQuizzes: userData.completedQuizzes || 0,
    subjectProgress: userData.subjectProgress || {}
  };

  await offlineStorage.saveUserProgress(progress);
};

export const syncOfflineData = async (): Promise<void> => {
  if (!navigator.onLine) {
    console.log('Cannot sync: device is offline');
    return;
  }

  try {
    // Get pending actions
    const pendingActions = await offlineStorage.getPendingOfflineActions();
    
    for (const action of pendingActions) {
      try {
        // In a real app, you would send this data to your server
        console.log('Syncing offline action:', action);
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Remove synced action
        await offlineStorage.removeOfflineAction(action.id);
        
      } catch (error) {
        console.error('Failed to sync action:', action.id, error);
        
        // Increment retry count
        action.retryCount++;
        if (action.retryCount > 3) {
          // Remove after 3 failed attempts
          await offlineStorage.removeOfflineAction(action.id);
        }
      }
    }
    
    console.log('Offline data sync completed');
  } catch (error) {
    console.error('Offline sync failed:', error);
  }
};

// Initialize storage on module load
offlineStorage.init().catch(console.error);

export default offlineStorage;

// Utility to check storage quota and usage
export const getStorageInfo = async (): Promise<{
  quota: number;
  usage: number;
  available: number;
}> => {
  if ('storage' in navigator && 'estimate' in navigator.storage) {
    const estimate = await navigator.storage.estimate();
    return {
      quota: estimate.quota || 0,
      usage: estimate.usage || 0,
      available: (estimate.quota || 0) - (estimate.usage || 0)
    };
  }
  
  return { quota: 0, usage: 0, available: 0 };
};

// Utility to request persistent storage
export const requestPersistentStorage = async (): Promise<boolean> => {
  if ('storage' in navigator && 'persist' in navigator.storage) {
    return await navigator.storage.persist();
  }
  return false;
};