// IndexedDB utilities for multilingual data storage

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
  difficulty: 'easy' | 'medium' | 'hard';
  subject: string;
  language: string;
}

interface QuizData {
  subject: string;
  language: string;
  questions: QuizQuestion[];
  lastUpdated: number;
}

interface TranslationData {
  language: string;
  translations: Record<string, string>;
  lastUpdated: number;
}

interface UserLanguagePreference {
  userId: string;
  primaryLanguage: string;
  secondaryLanguages: string[];
  lastUpdated: number;
}

class MultilingualDB {
  private dbName = 'EduSparkMultilingual';
  private dbVersion = 1;
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Quiz questions store
        if (!db.objectStoreNames.contains('quizQuestions')) {
          const quizStore = db.createObjectStore('quizQuestions', { keyPath: ['subject', 'language'] });
          quizStore.createIndex('subject', 'subject', { unique: false });
          quizStore.createIndex('language', 'language', { unique: false });
          quizStore.createIndex('difficulty', 'difficulty', { unique: false });
        }

        // Translations store
        if (!db.objectStoreNames.contains('translations')) {
          const translationStore = db.createObjectStore('translations', { keyPath: 'language' });
        }

        // User language preferences store
        if (!db.objectStoreNames.contains('userLanguagePrefs')) {
          const userPrefStore = db.createObjectStore('userLanguagePrefs', { keyPath: 'userId' });
        }

        // Quiz results by language store
        if (!db.objectStoreNames.contains('quizResults')) {
          const resultsStore = db.createObjectStore('quizResults', { keyPath: 'id', autoIncrement: true });
          resultsStore.createIndex('userId', 'userId', { unique: false });
          resultsStore.createIndex('language', 'language', { unique: false });
          resultsStore.createIndex('subject', 'subject', { unique: false });
          resultsStore.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }

  async saveQuizQuestions(subject: string, language: string, questions: QuizQuestion[]): Promise<void> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['quizQuestions'], 'readwrite');
    const store = transaction.objectStore('quizQuestions');

    const quizData: QuizData = {
      subject,
      language,
      questions,
      lastUpdated: Date.now()
    };

    return new Promise((resolve, reject) => {
      const request = store.put(quizData);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getQuizQuestions(subject: string, language: string): Promise<QuizQuestion[]> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['quizQuestions'], 'readonly');
    const store = transaction.objectStore('quizQuestions');

    return new Promise((resolve, reject) => {
      const request = store.get([subject, language]);
      request.onsuccess = () => {
        const result = request.result as QuizData;
        resolve(result ? result.questions : []);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveTranslations(language: string, translations: Record<string, string>): Promise<void> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['translations'], 'readwrite');
    const store = transaction.objectStore('translations');

    const translationData: TranslationData = {
      language,
      translations,
      lastUpdated: Date.now()
    };

    return new Promise((resolve, reject) => {
      const request = store.put(translationData);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getTranslations(language: string): Promise<Record<string, string>> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['translations'], 'readonly');
    const store = transaction.objectStore('translations');

    return new Promise((resolve, reject) => {
      const request = store.get(language);
      request.onsuccess = () => {
        const result = request.result as TranslationData;
        resolve(result ? result.translations : {});
      };
      request.onerror = () => reject(request.error);
    });
  }

  async saveUserLanguagePreference(userId: string, primaryLanguage: string, secondaryLanguages: string[] = []): Promise<void> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['userLanguagePrefs'], 'readwrite');
    const store = transaction.objectStore('userLanguagePrefs');

    const preference: UserLanguagePreference = {
      userId,
      primaryLanguage,
      secondaryLanguages,
      lastUpdated: Date.now()
    };

    return new Promise((resolve, reject) => {
      const request = store.put(preference);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getUserLanguagePreference(userId: string): Promise<UserLanguagePreference | null> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['userLanguagePrefs'], 'readonly');
    const store = transaction.objectStore('userLanguagePrefs');

    return new Promise((resolve, reject) => {
      const request = store.get(userId);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  async saveQuizResult(userId: string, subject: string, language: string, score: number, totalQuestions: number, answers: any[]): Promise<void> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['quizResults'], 'readwrite');
    const store = transaction.objectStore('quizResults');

    const result = {
      userId,
      subject,
      language,
      score,
      totalQuestions,
      answers,
      timestamp: Date.now()
    };

    return new Promise((resolve, reject) => {
      const request = store.add(result);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  async getQuizResultsByLanguage(userId: string, language: string): Promise<any[]> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['quizResults'], 'readonly');
    const store = transaction.objectStore('quizResults');
    const index = store.index('language');

    return new Promise((resolve, reject) => {
      const request = index.getAll(language);
      request.onsuccess = () => {
        const results = request.result.filter(result => result.userId === userId);
        resolve(results);
      };
      request.onerror = () => reject(request.error);
    });
  }

  async getAllAvailableLanguages(): Promise<string[]> {
    if (!this.db) await this.init();

    const transaction = this.db!.transaction(['quizQuestions'], 'readonly');
    const store = transaction.objectStore('quizQuestions');
    const index = store.index('language');

    return new Promise((resolve, reject) => {
      const request = index.getAllKeys();
      request.onsuccess = () => {
        const languages = [...new Set(request.result as string[])];
        resolve(languages);
      };
      request.onerror = () => reject(request.error);
    });
  }
}

// Create singleton instance
export const multilingualDB = new MultilingualDB();

// Comprehensive Quiz question data for different Indian languages and subjects
export const sampleQuizData: Record<string, Record<string, QuizQuestion[]>> = {
  mathematics: {
    en: [
      {
        id: 'math_en_1',
        question: 'What is 12 + 8?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'en'
      },
      {
        id: 'math_en_2',
        question: 'What is 15 × 3?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'en'
      },
      {
        id: 'math_en_3',
        question: 'What is the square root of 64?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 because 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'en'
      }
    ],
    hi: [
      {
        id: 'math_hi_1',
        question: '12 + 8 कितना होता है?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'hi'
      },
      {
        id: 'math_hi_2',
        question: '15 × 3 कितना होता है?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'hi'
      },
      {
        id: 'math_hi_3',
        question: '64 का वर्गमूल क्या है?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 क्योंकि 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'hi'
      }
    ],
    bn: [
      {
        id: 'math_bn_1',
        question: '12 + 8 কত?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'bn'
      },
      {
        id: 'math_bn_2',
        question: '15 × 3 কত?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'bn'
      },
      {
        id: 'math_bn_3',
        question: '64 এর বর্গমূল কত?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 কারণ 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'bn'
      }
    ],
    te: [
      {
        id: 'math_te_1',
        question: '12 + 8 ఎంత?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'te'
      },
      {
        id: 'math_te_2',
        question: '15 × 3 ఎంత?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'te'
      },
      {
        id: 'math_te_3',
        question: '64 యొక్క వర్గమూలం ఎంత?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 ఎందుకంటే 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'te'
      }
    ],
    ta: [
      {
        id: 'math_ta_1',
        question: '12 + 8 என்ன?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'ta'
      },
      {
        id: 'math_ta_2',
        question: '15 × 3 என்ன?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'ta'
      },
      {
        id: 'math_ta_3',
        question: '64 இன் வர்க்கமூலம் என்ன?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 ஏனென்றால் 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'ta'
      }
    ],
    gu: [
      {
        id: 'math_gu_1',
        question: '12 + 8 કેટલું થાય?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'gu'
      },
      {
        id: 'math_gu_2',
        question: '15 × 3 કેટલું થાય?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'gu'
      },
      {
        id: 'math_gu_3',
        question: '64 નું વર્ગમૂળ કેટલું છે?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 કારણ કે 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'gu'
      }
    ],
    mr: [
      {
        id: 'math_mr_1',
        question: '12 + 8 किती होते?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'mr'
      },
      {
        id: 'math_mr_2',
        question: '15 × 3 किती होते?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'mr'
      },
      {
        id: 'math_mr_3',
        question: '64 चे वर्गमूळ काय आहे?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 कारण 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'mr'
      }
    ],
    kn: [
      {
        id: 'math_kn_1',
        question: '12 + 8 ಎಷ್ಟು?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'kn'
      },
      {
        id: 'math_kn_2',
        question: '15 × 3 ಎಷ್ಟು?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'kn'
      },
      {
        id: 'math_kn_3',
        question: '64 ರ ವರ್ಗಮೂಲ ಎಷ್ಟು?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 ಏಕೆಂದರೆ 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'kn'
      }
    ],
    ml: [
      {
        id: 'math_ml_1',
        question: '12 + 8 എത്ര?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'ml'
      },
      {
        id: 'math_ml_2',
        question: '15 × 3 എത്ര?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'ml'
      },
      {
        id: 'math_ml_3',
        question: '64 ന്റെ വർഗമൂലം എത്ര?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 കാരണം 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'ml'
      }
    ],
    pa: [
      {
        id: 'math_pa_1',
        question: '12 + 8 ਕਿੰਨਾਂ ਹੁੰਦਾ ਹੈ?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'pa'
      },
      {
        id: 'math_pa_2',
        question: '15 × 3 ਕਿੰਨਾਂ ਹੁੰਦਾ ਹੈ?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'pa'
      },
      {
        id: 'math_pa_3',
        question: '64 ਦਾ ਵਰਗਮੂਲ ਕੀ ਹੈ?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 ਕਿਉਂਕਿ 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'pa'
      }
    ],
    or: [
      {
        id: 'math_or_1',
        question: '12 + 8 କେତେ?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'or'
      },
      {
        id: 'math_or_2',
        question: '15 × 3 କେତେ?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'or'
      },
      {
        id: 'math_or_3',
        question: '64 ର ବର୍ଗମୂଳ କେତେ?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 କାରଣ 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'or'
      }
    ],
    as: [
      {
        id: 'math_as_1',
        question: '12 + 8 কিমান?',
        options: ['18', '20', '22', '24'],
        correctAnswer: 1,
        explanation: '12 + 8 = 20',
        difficulty: 'easy',
        subject: 'mathematics',
        language: 'as'
      },
      {
        id: 'math_as_2',
        question: '15 × 3 কিমান?',
        options: ['35', '40', '45', '50'],
        correctAnswer: 2,
        explanation: '15 × 3 = 45',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'as'
      },
      {
        id: 'math_as_3',
        question: '64 ৰ বৰ্গমূল কিমান?',
        options: ['6', '7', '8', '9'],
        correctAnswer: 2,
        explanation: '√64 = 8 কাৰণ 8 × 8 = 64',
        difficulty: 'medium',
        subject: 'mathematics',
        language: 'as'
      }
    ]
  },
  science: {
    en: [
      {
        id: 'sci_en_1',
        question: 'What is the chemical symbol for water?',
        options: ['H2O', 'CO2', 'O2', 'H2SO4'],
        correctAnswer: 0,
        explanation: 'Water is composed of two hydrogen atoms and one oxygen atom: H2O',
        difficulty: 'easy',
        subject: 'science',
        language: 'en'
      },
      {
        id: 'sci_en_2',
        question: 'Which planet is closest to the Sun?',
        options: ['Venus', 'Mercury', 'Earth', 'Mars'],
        correctAnswer: 1,
        explanation: 'Mercury is the closest planet to the Sun in our solar system',
        difficulty: 'easy',
        subject: 'science',
        language: 'en'
      },
      {
        id: 'sci_en_3',
        question: 'What gas do plants absorb from the atmosphere during photosynthesis?',
        options: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Hydrogen'],
        correctAnswer: 2,
        explanation: 'Plants absorb carbon dioxide during photosynthesis to make glucose',
        difficulty: 'medium',
        subject: 'science',
        language: 'en'
      }
    ],
    hi: [
      {
        id: 'sci_hi_1',
        question: 'पानी का रासायनिक चिह्न क्या है?',
        options: ['H2O', 'CO2', 'O2', 'H2SO4'],
        correctAnswer: 0,
        explanation: 'पानी दो हाइड्रोजन परमाणुओं और एक ऑक्सीजन परमाणु से बना है: H2O',
        difficulty: 'easy',
        subject: 'science',
        language: 'hi'
      },
      {
        id: 'sci_hi_2',
        question: 'सूर्य के सबसे निकट कौन सा ग्रह है?',
        options: ['शुक्र', 'बुध', 'पृथ्वी', 'मंगल'],
        correctAnswer: 1,
        explanation: 'बुध हमारे सौर मंडल में सूर्य के सबसे निकट का ग्रह है',
        difficulty: 'easy',
        subject: 'science',
        language: 'hi'
      },
      {
        id: 'sci_hi_3',
        question: 'प्रकाश संश्लेषण के दौरान पौधे वायुमंडल से कौन सी गैस अवशोषित करते हैं?',
        options: ['ऑक्सीजन', 'नाइट्रोजन', 'कार्बन डाइऑक्साइड', 'हाइड्रोजन'],
        correctAnswer: 2,
        explanation: 'पौधे ग्लूकोज बनाने के लिए प्रकाश संश्लेषण के दौरान कार्बन डाइऑक्साइड अवशोषित करते हैं',
        difficulty: 'medium',
        subject: 'science',
        language: 'hi'
      }
    ],
    bn: [
      {
        id: 'sci_bn_1',
        question: 'পানির রাসায়নিক চিহ্ন কী?',
        options: ['H2O', 'CO2', 'O2', 'H2SO4'],
        correctAnswer: 0,
        explanation: 'পানি দুটি হাইড্রোজেন পরমাণু এবং একটি অক্সিজেন পরমাণু দিয়ে গঠিত: H2O',
        difficulty: 'easy',
        subject: 'science',
        language: 'bn'
      },
      {
        id: 'sci_bn_2',
        question: 'সূর্যের সবচেয়ে কাছের গ্রহ কোনটি?',
        options: ['শুক্র', 'বুধ', 'পৃথিবী', 'মঙ্গল'],
        correctAnswer: 1,
        explanation: 'বুধ আমাদের সৌরজগতে সূর্যের সবচেয়ে কাছের গ্রহ',
        difficulty: 'easy',
        subject: 'science',
        language: 'bn'
      },
      {
        id: 'sci_bn_3',
        question: 'সালোকসংশ্লেষণের সময় গাছপালা বায়ুমণ্ডল থেকে কোন গ্যাস শোষণ করে?',
        options: ['অক্সিজেন', 'নাইট্রোজেন', 'কার্বন ডাইঅক্সাইড', 'হাইড্রোজেন'],
        correctAnswer: 2,
        explanation: 'গাছপালা গ্লুকোজ তৈরি করতে সালোকসংশ্লেষণের সময় কার্বন ডাইঅক্সাইড শোষণ করে',
        difficulty: 'medium',
        subject: 'science',
        language: 'bn'
      }
    ],
    te: [
      {
        id: 'sci_te_1',
        question: 'నీటి రసాయన చిహ్నం ఏమిటి?',
        options: ['H2O', 'CO2', 'O2', 'H2SO4'],
        correctAnswer: 0,
        explanation: 'నీరు రెండు హైడ్రోజన్ పరమాణువులు మరియు ఒక ఆక్సిజన్ పరమాణువుతో కూడినది: H2O',
        difficulty: 'easy',
        subject: 'science',
        language: 'te'
      },
      {
        id: 'sci_te_2',
        question: 'సూర్యుడికి అత్యంత దగ్గరగా ఉన్న గ్రహం ఏది?',
        options: ['శుక్రుడు', 'బుధుడు', 'భూమి', 'అంగారకుడు'],
        correctAnswer: 1,
        explanation: 'బుధుడు మన సౌర వ్యవస్థలో సూర్యుడికి అత్యంత దగ్గరగా ఉన్న గ్రహం',
        difficulty: 'easy',
        subject: 'science',
        language: 'te'
      },
      {
        id: 'sci_te_3',
        question: 'కిరణజన్య సంయోగక్రియ సమయంలో మొక్కలు వాతావరణం నుండి ఏ వాయువును గ్రహిస్తాయి?',
        options: ['ఆక్సిజన్', 'నైట్రోజన్', 'కార్బన్ డైఆక్సైడ్', 'హైడ్రోజన్'],
        correctAnswer: 2,
        explanation: 'మొక్కలు గ్లూకోజ్ తయారు చేయడానికి కిరణజన్య సంయోగక్రియ సమయంలో కార్బన్ డైఆక్సైడ్ను గ్రహిస్తాయి',
        difficulty: 'medium',
        subject: 'science',
        language: 'te'
      }
    ],
    ta: [
      {
        id: 'sci_ta_1',
        question: 'நீரின் வேதியியல் குறியீடு என்ன?',
        options: ['H2O', 'CO2', 'O2', 'H2SO4'],
        correctAnswer: 0,
        explanation: 'நீர் இரண்டு ஹைட்ரஜன் அணுக்கள் மற்றும் ஒரு ஆக்சிஜன் அணுவால் ஆனது: H2O',
        difficulty: 'easy',
        subject: 'science',
        language: 'ta'
      },
      {
        id: 'sci_ta_2',
        question: 'சூரியனுக்கு மிக அருகில் உள்ள கிரகம் எது?',
        options: ['வெள்ளி', 'புதன்', 'பூமி', 'செவ்வாய்'],
        correctAnswer: 1,
        explanation: 'புதன் நமது சூரிய குடும்பத்தில் சூரியனுக்கு மிக அருகில் உள்ள கிரகம்',
        difficulty: 'easy',
        subject: 'science',
        language: 'ta'
      },
      {
        id: 'sci_ta_3',
        question: 'ஒளிச்சேர்க்கையின் போது தாவரங்கள் வளிமண்டலத்திலிருந்து எந்த வாயுவை உறிஞ்சுகின்றன?',
        options: ['ஆக்சிஜன்', 'நைட்ரஜன்', 'கார்பன் டை ஆக்சைடு', 'ஹைட்ரஜன்'],
        correctAnswer: 2,
        explanation: 'தாவரங்கள் குளுக்கோஸ் தயாரிக்க ஒளிச்சேர்க்கையின் போது கார்பன் டை ஆக்சைடை உறிஞ்சுகின்றன',
        difficulty: 'medium',
        subject: 'science',
        language: 'ta'
      }
    ]
  },
  geography: {
    en: [
      {
        id: 'geo_en_1',
        question: 'Which is the largest continent by area?',
        options: ['Africa', 'Asia', 'North America', 'Europe'],
        correctAnswer: 1,
        explanation: 'Asia is the largest continent covering about 30% of Earth\'s land area',
        difficulty: 'easy',
        subject: 'geography',
        language: 'en'
      },
      {
        id: 'geo_en_2',
        question: 'Which river is the longest in the world?',
        options: ['Amazon', 'Nile', 'Yangtze', 'Mississippi'],
        correctAnswer: 1,
        explanation: 'The Nile River is approximately 6,650 km long, making it the longest river',
        difficulty: 'medium',
        subject: 'geography',
        language: 'en'
      }
    ],
    hi: [
      {
        id: 'geo_hi_1',
        question: 'क्षेत्रफल की दृष्टि से सबसे बड़ा महाद्वीप कौन सा है?',
        options: ['अफ्रीका', 'एशिया', 'उत्तरी अमेरिका', 'यूरोप'],
        correctAnswer: 1,
        explanation: 'एशिया सबसे बड़ा महाद्वीप है जो पृथ्वी के भू-भाग का लगभग 30% हिस्सा घेरता है',
        difficulty: 'easy',
        subject: 'geography',
        language: 'hi'
      },
      {
        id: 'geo_hi_2',
        question: 'विश्व की सबसे लंबी नदी कौन सी है?',
        options: ['अमेज़न', 'नील', 'यांग्त्ज़े', 'मिसिसिपी'],
        correctAnswer: 1,
        explanation: 'नील नदी लगभग 6,650 किमी लंबी है, जो इसे सबसे लंबी नदी बनाती है',
        difficulty: 'medium',
        subject: 'geography',
        language: 'hi'
      }
    ]
  },
  history: {
    en: [
      {
        id: 'hist_en_1',
        question: 'Who was the first Prime Minister of India?',
        options: ['Mahatma Gandhi', 'Jawaharlal Nehru', 'Sardar Patel', 'Dr. Rajendra Prasad'],
        correctAnswer: 1,
        explanation: 'Jawaharlal Nehru was the first Prime Minister of independent India',
        difficulty: 'easy',
        subject: 'history',
        language: 'en'
      },
      {
        id: 'hist_en_2',
        question: 'In which year did India gain independence?',
        options: ['1945', '1946', '1947', '1948'],
        correctAnswer: 2,
        explanation: 'India gained independence from British rule on August 15, 1947',
        difficulty: 'easy',
        subject: 'history',
        language: 'en'
      }
    ],
    hi: [
      {
        id: 'hist_hi_1',
        question: 'भारत के पहले प्रधानमंत्री कौन थे?',
        options: ['महात्मा गांधी', 'जवाहरलाल नेहरू', 'सरदार पटेल', 'डॉ. राजेंद्र प्रसाद'],
        correctAnswer: 1,
        explanation: 'जवाहरलाल नेहरू स्वतंत्र भारत के पहले प्रधानमंत्री थे',
        difficulty: 'easy',
        subject: 'history',
        language: 'hi'
      },
      {
        id: 'hist_hi_2',
        question: 'भारत को स्वतंत्रता किस वर्ष मिली?',
        options: ['1945', '1946', '1947', '1948'],
        correctAnswer: 2,
        explanation: 'भारत को 15 अगस्त 1947 को ब्रिटिश शासन से स्वतंत्रता मिली',
        difficulty: 'easy',
        subject: 'history',
        language: 'hi'
      }
    ]
  }
};

// Initialize sample data
export const initializeSampleData = async (): Promise<void> => {
  try {
    await multilingualDB.init();
    
    // Save quiz data for all subjects and languages
    for (const subject in sampleQuizData) {
      for (const language in sampleQuizData[subject]) {
        await multilingualDB.saveQuizQuestions(
          subject,
          language,
          sampleQuizData[subject][language]
        );
      }
    }
    
    console.log('Sample multilingual quiz data initialized');
  } catch (error) {
    console.error('Failed to initialize sample data:', error);
  }
};