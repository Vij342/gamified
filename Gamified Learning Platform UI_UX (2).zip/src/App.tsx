import { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { WelcomeScreen } from "./components/WelcomeScreen";
import { StudentLogin } from "./components/StudentLogin";
import { SkillAssessment } from "./components/SkillAssessment";
import { HomePage } from "./components/HomePage";
import { Dashboard } from "./components/Dashboard";
import { MultilingualDashboard } from "./components/MultilingualDashboard";
import { MultilingualQuiz } from "./components/MultilingualQuiz";
import { QuizGame } from "./components/QuizGame";
import { FractionGame } from "./components/FractionGame";
import { InteractiveQuiz } from "./components/InteractiveQuiz";
import { QuizResults } from "./components/QuizResults";
import { ProgressReport } from "./components/ProgressReport";
import { Achievements } from "./components/Achievements";
import { Leaderboard } from "./components/Leaderboard";
import { BadgesPage } from "./components/BadgesPage";
import { TeacherTracking } from "./components/TeacherTracking";
import { FamilyTracking } from "./components/FamilyTracking";
import { HelpPage } from "./components/HelpPage";
import { ContactPage } from "./components/ContactPage";
import { OfflineDetector } from "./components/OfflineDetector";
import { PWAInstaller } from "./components/PWAInstaller";
import { saveQuizOffline, saveUserProgressOffline, syncOfflineData } from "./utils/offlineStorage";
import { multilingualDB, initializeSampleData } from "./utils/multilingualStorage";

type AppState = "welcome" | "login" | "assessment" | "home" | "dashboard" | "multilingualDashboard" | "multilingualQuiz" | "quiz" | "fractionGame" | "interactiveQuiz" | "results" | "progress" | "achievements" | "leaderboard" | "badges" | "teacher" | "family" | "help" | "contact";

interface UserData {
  name: string;
  avatar: string;
  level: number;
  xp: number;
  xpToNext: number;
  streak: number;
  coins: number;
  grade?: number;
  deviceId?: string;
  skillLevel?: string;
  language?: string;
}

interface QuizResultData {
  score: number;
  totalQuestions: number;
  xpEarned: number;
  subject: string;
}

export default function App() {
  // Check if user has completed onboarding
  const [currentState, setCurrentState] = useState<AppState>(() => {
    const saved = localStorage.getItem("eduspark-user");
    const userData = saved ? JSON.parse(saved) : null;
    return userData && userData.name !== "Scholar" ? "home" : "welcome";
  });
  
  const [selectedSubject, setSelectedSubject] = useState<string>("");
  const [quizResult, setQuizResult] = useState<QuizResultData | null>(null);
  const [selectedLanguage, setSelectedLanguage] = useState<string>(() => {
    const saved = localStorage.getItem("eduspark-language");
    return saved || "en";
  });
  
  // Load user data from localStorage or use defaults
  const [userData, setUserData] = useState<UserData>(() => {
    const saved = localStorage.getItem("eduspark-user");
    return saved ? JSON.parse(saved) : {
      name: "Scholar",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop&crop=face",
      level: 0,
      xp: 0,
      xpToNext: 100,
      streak: 0,
      coins: 0,
      language: "en"
    };
  });

  // Save user data to localStorage and IndexedDB whenever it changes
  useEffect(() => {
    localStorage.setItem("eduspark-user", JSON.stringify(userData));
    
    // Also save to IndexedDB for better offline support
    saveUserProgressOffline(userData).catch(console.error);
  }, [userData]);

  // Initialize service worker, offline features, and multilingual data
  useEffect(() => {
    // Initialize multilingual database
    initializeSampleData().catch(console.error);
    
    // Register service worker
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', async () => {
        try {
          const registration = await navigator.serviceWorker.register('/sw.js');
          console.log('SW registered:', registration);

          // Handle service worker updates
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  // New content is available, refresh to update
                  console.log('New content available, refreshing...');
                  window.location.reload();
                }
              });
            }
          });

          // Handle offline sync when coming back online
          window.addEventListener('online', () => {
            syncOfflineData().catch(console.error);
          });

        } catch (error) {
          console.log('SW registration failed:', error);
        }
      });
    }

    // Initial sync if online
    if (navigator.onLine) {
      syncOfflineData().catch(console.error);
    }
  }, []);

  const handleStartQuiz = (subjectId: string) => {
    setSelectedSubject(subjectId);
    if (subjectId === "fractionFun") {
      setCurrentState("fractionGame");
    } else if (subjectId === "interactiveQuiz") {
      setCurrentState("interactiveQuiz");
    } else {
      // Check if subject has multilingual support
      setCurrentState("multilingualQuiz");
    }
  };

  const handleWelcomeContinue = (language: string) => {
    setSelectedLanguage(language);
    localStorage.setItem("eduspark-language", language);
    setCurrentState("login");
  };

  const handleStudentLogin = (name: string, grade: number, deviceId: string) => {
    const updatedUserData = {
      ...userData,
      name,
      grade,
      deviceId,
      language: selectedLanguage,
      avatar: `https://images.unsplash.com/photo-${Math.floor(Math.random() * 10) + 1535713875002}-d1d0cf377fde?w=150&h=150&fit=crop&crop=face`
    };
    setUserData(updatedUserData);
    setCurrentState("assessment");
  };

  const handleAssessmentComplete = (skillLevel: string) => {
    const updatedUserData = {
      ...userData,
      skillLevel
    };
    setUserData(updatedUserData);
    setCurrentState("home");
  };

  const handleQuizComplete = async (score: number, xpEarned: number) => {
    // Update user data
    let newXP = userData.xp + xpEarned;
    let newLevel = userData.level;
    let newXPToNext = userData.xpToNext;
    
    // Level up logic - starting from level 0
    while (newXP >= newXPToNext) {
      newLevel += 1;
      newXP -= newXPToNext; // Carry over excess XP
      newXPToNext = 100 + (newLevel * 50); // Progressive XP requirements: 100, 150, 200, 250, etc.
    }
    
    const newCoins = userData.coins + Math.round(xpEarned / 10);
    const newStreak = userData.streak + 1;

    const updatedUserData = {
      ...userData,
      xp: newXP,
      level: newLevel,
      xpToNext: newXPToNext,
      coins: newCoins,
      streak: newStreak
    };

    setUserData(updatedUserData);

    // Save quiz completion offline
    try {
      const totalQuestions = 3; // This would come from the actual quiz
      await saveQuizOffline(
        selectedSubject,
        score,
        totalQuestions,
        xpEarned,
        [] // Quiz answers would be passed here in real implementation
      );
    } catch (error) {
      console.error('Failed to save quiz offline:', error);
    }

    // Set quiz results
    setQuizResult({
      score,
      totalQuestions: 3,
      xpEarned,
      subject: getSubjectName(selectedSubject)
    });
    
    setCurrentState("results");
  };

  const getSubjectName = (subjectId: string) => {
    const subjects: Record<string, string> = {
      math: "Mathematics",
      science: "Science", 
      english: "English",
      geography: "Geography",
      history: "History",
      art: "Art & Culture"
    };
    return subjects[subjectId] || "Quiz";
  };

  const handleRetakeQuiz = () => {
    setCurrentState("quiz");
  };

  const handleBackToDashboard = () => {
    setCurrentState("dashboard");
    setQuizResult(null);
    setSelectedSubject("");
  };

  const handleViewAchievements = () => {
    setCurrentState("achievements");
  };

  const handleViewLeaderboard = () => {
    setCurrentState("leaderboard");
  };

  const handleViewProgress = () => {
    setCurrentState("progress");
  };

  const handleNavigate = (state: AppState) => {
    setCurrentState(state);
    // Reset quiz data when navigating away from quiz-related screens
    if (state !== "quiz" && state !== "results" && state !== "fractionGame" && state !== "interactiveQuiz" && state !== "multilingualQuiz") {
      setQuizResult(null);
      setSelectedSubject("");
    }
  };

  const handleSettings = () => {
    // Settings functionality could be added here
    console.log("Settings clicked");
  };

  const handleRetryConnection = () => {
    if (navigator.onLine) {
      syncOfflineData().catch(console.error);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Offline Detection */}
      <OfflineDetector onRetry={handleRetryConnection} />
      
      {/* PWA Install Prompt */}
      <PWAInstaller />

      {/* Header - show on specific screens */}
      {!["welcome", "login", "assessment", "quiz", "fractionGame", "interactiveQuiz", "multilingualQuiz", "multilingualDashboard"].includes(currentState) && (
        <Header 
          user={userData}
          currentState={currentState}
          onNavigate={handleNavigate}
          onSettingsClick={handleSettings}
        />
      )}

      {/* Main Content */}
      <main className={!["quiz", "fractionGame", "interactiveQuiz", "multilingualQuiz", "welcome", "login", "assessment"].includes(currentState) ? "pt-0" : ""}>
        {currentState === "welcome" && (
          <WelcomeScreen onContinue={handleWelcomeContinue} />
        )}

        {currentState === "login" && (
          <StudentLogin 
            language={selectedLanguage}
            onLogin={handleStudentLogin}
            onBack={() => setCurrentState("welcome")}
          />
        )}

        {currentState === "assessment" && (
          <SkillAssessment
            language={selectedLanguage}
            onComplete={handleAssessmentComplete}
            onBack={() => setCurrentState("login")}
          />
        )}
        
        {currentState === "home" && (
          <HomePage onNavigate={handleNavigate} />
        )}
        
        {currentState === "dashboard" && (
          <Dashboard
            onStartQuiz={handleStartQuiz}
            onViewLeaderboard={handleViewLeaderboard}
            onViewAchievements={handleViewAchievements}
            onViewProgress={handleViewProgress}
            onMultilingualDashboard={() => handleNavigate("multilingualDashboard")}
          />
        )}

        {currentState === "multilingualDashboard" && (
          <MultilingualDashboard
            onStartQuiz={handleStartQuiz}
            onViewLeaderboard={handleViewLeaderboard}
            onViewAchievements={handleViewAchievements}
            onViewProgress={handleViewProgress}
            onBack={() => handleNavigate("dashboard")}
            defaultLanguage={selectedLanguage}
          />
        )}

        {currentState === "multilingualQuiz" && (
          <MultilingualQuiz
            subject={selectedSubject}
            onBack={handleBackToDashboard}
            onComplete={handleQuizComplete}
            defaultLanguage={selectedLanguage}
          />
        )}
        
        {currentState === "quiz" && (
          <QuizGame
            subjectId={selectedSubject}
            onBack={handleBackToDashboard}
            onComplete={handleQuizComplete}
          />
        )}

        {currentState === "fractionGame" && (
          <FractionGame
            onBack={handleBackToDashboard}
            onComplete={handleQuizComplete}
          />
        )}

        {currentState === "interactiveQuiz" && (
          <InteractiveQuiz
            subject={selectedSubject}
            onBack={handleBackToDashboard}
            onComplete={handleQuizComplete}
          />
        )}
        
        {currentState === "results" && quizResult && (
          <QuizResults
            score={quizResult.score}
            totalQuestions={quizResult.totalQuestions}
            xpEarned={quizResult.xpEarned}
            subject={quizResult.subject}
            onRetakeQuiz={handleRetakeQuiz}
            onBackToDashboard={handleBackToDashboard}
          />
        )}

        {currentState === "progress" && (
          <ProgressReport
            onContinueLearning={() => handleNavigate("dashboard")}
            onBack={() => handleNavigate("dashboard")}
          />
        )}
        
        {currentState === "achievements" && (
          <Achievements onBack={() => handleNavigate("dashboard")} />
        )}
        
        {currentState === "leaderboard" && (
          <Leaderboard onBack={() => handleNavigate("dashboard")} />
        )}
        
        {currentState === "badges" && (
          <BadgesPage onBack={() => handleNavigate("dashboard")} />
        )}
        
        {currentState === "teacher" && (
          <TeacherTracking onBack={() => handleNavigate("home")} />
        )}
        
        {currentState === "family" && (
          <FamilyTracking onBack={() => handleNavigate("home")} />
        )}
        
        {currentState === "help" && (
          <HelpPage 
            onBack={() => handleNavigate("home")} 
            onContact={() => handleNavigate("contact")}
          />
        )}
        
        {currentState === "contact" && (
          <ContactPage onBack={() => handleNavigate("help")} />
        )}
      </main>
    </div>
  );
}